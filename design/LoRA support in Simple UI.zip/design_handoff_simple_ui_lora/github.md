repo: SceneWorks/SceneWorks
branch: main
path: apps/web/src

## Last sync

date: 2026-07-27T16:59:15Z

### Updated in this project

- Recreated the Simple UI shell + Image/Video studios from `apps/web/src/simple/`.
- Added a LoRA control as the last row of the Simple settings bar (slots, trigger keywords, −2…2 weight slider).
- Added an Add LoRA picker sheet with a collapsed inline import (URL / Upload, name, trigger keywords).
- Responsive across the three measured Simple bands (phone / tablet / desktop).

## Screen map

| Project screen | Repo files |
| --- | --- |
| Simple UI LoRA.dc.html (canvas) | — assembles the frames below |
| SimpleStudio.dc.html — Image | simple/SimpleImageStudio.jsx, simple/studioParts.jsx, simple/SimpleShell.jsx, simple/SimpleModeSwitch.jsx, simple/simple.css, simple/breakpoint.js, simple/modelDefaults.js, components/Icons.jsx, components/Logo.jsx |
| SimpleStudio.dc.html — Video | simple/SimpleVideoStudio.jsx, simple/studioParts.jsx, simple/SimpleShell.jsx, simple/simple.css |
| SimpleStudio.dc.html — LoRA row | components/generationStudio.jsx (LoraPickerSection), components/LoraKeywordSummary.jsx, components/LoraPickerField.jsx, presetUtils.js (LORA_WEIGHT_MIN/MAX/STEP, MAX_USER_JOB_LORAS, loraWeight) |
| LoraSheet.dc.html | simple/SimpleSheet.jsx, components/StudioLoraImportPanel.jsx, components/KeywordTagEditor.jsx, screens/ModelManagerScreen.jsx (importLora) |
| Style strip labels | data/styleCatalog.js, data/styles.json (group names) |
| Job payload contract (for reference) | simple/simpleJobs.js, presetUtils.js (serializeLora) |
