# Handoff: LoRA support in the Simple UI studios

## Overview

Adds LoRA selection — and LoRA import — to the **Simple** shell's Image Studio and Video Studio in `SceneWorks/SceneWorks` (`apps/web/src/simple/`). Today LoRAs are only reachable from the Advanced workspace (`components/generationStudio.jsx` → `LoraPickerSection`) and from Model Manager; Simple exposes none, so a Simple user cannot apply a style/motion adapter or bring in a `.safetensors` they already have.

The design keeps Simple's rule intact: **the reduced surface is which knobs are shown, not what gets submitted.** The control produces the same `loras: [serializeLora(lora, { weight })]` array the advanced studios send, so `buildSimpleImageRequest` / `buildSimpleVideoRequest` only need to stop hardcoding `loras: []`.

Scope of this design:
- A LoRA row inside the existing Simple settings bar (Image + Video).
- An **Add LoRA** picker sheet reusing Simple's one sheet chrome (`SimpleSheet`).
- Inline LoRA import (URL or file upload) collapsed inside that sheet.
- A pending-import slot while the import job runs.
- Responsive across all three Simple bands.

Explicitly **out** of scope: "Show incompatible" (the studios already hide it), scope/family pickers (auto-detected), notes display, the Wan A14B two-expert manual slot (stays a Model Manager concern), presets/preset-seeded LoRAs.

## About the design files

The files in `design/` are **design references created in HTML** — prototypes showing intended look and behavior, not production code to copy. The task is to **recreate them inside the existing `apps/web` React app**, using its established patterns: real `.jsx` components under `apps/web/src/simple/`, class names added to `apps/web/src/simple/simple.css` under the existing `su-*` namespace, and the real hooks/context (`useAppContext`, `useSimpleUi`, `useModelsAndLoras`). Do **not** ship inline styles — the prototype uses them only because of its authoring environment. Every value in it maps to a token already defined in `apps/web/src/styles.css`.

## Fidelity

**High-fidelity.** The surrounding shell (sidebar, topbar, tabs, prompt, tiles, settings bar, style strip, Generate) is a pixel recreation of the current code, so the new LoRA block should land pixel-perfectly. Colors, radii, control heights and type sizes are all existing tokens — no new palette, no new radius, no new font size that isn't already in `simple.css`.

## Screens / views

### 1. Simple Image Studio (`SimpleImageStudio.jsx`)

**Purpose** — text-to-image / edit runs with a reduced control surface.

**Layout (unchanged)** — `.su-screen` is `display:flex; flex-direction:column; gap:14px; padding:18px` inside `.su-content` (`max-width: var(--su-content-max)`: 900px desktop, 680px tablet, none on phone). Order: mode tabs → prompt → tile grid (Reference / Refine) → `.su-settings-bar` → style strip → Generate.

**New** — the LoRA block is the **last child of `.su-settings-bar`**, directly under the Variations chips. It is inside the bar, not a card of its own, so it reads as a peer of Model / Resolution / Variations — the same decision `LoraPickerSection` made when it moved into the advanced settings bar (sc-15370).

Screenshots: `screenshots/01-image-studio-desktop.png`, `02-image-studio-tablet.png`, `03-image-studio-phone.png`.

### 2. Simple Video Studio (`SimpleVideoStudio.jsx`)

Identical block in the identical position, listing only LoRAs whose family matches the selected video model. One addition below the Add LoRA row:

> Wan 2.2 A14B LoRAs are trained as a high/low-noise pair — selecting one loads both experts.

Rendered as an `Icon.Info`-prefixed hint line (11px, `--text-muted`, icon `--text-faint`), not a bordered notice — it is context, not a warning. Show it only when the selected model's family declares the A14B mixture-of-experts pair.

Screenshots: `04-video-studio-desktop.png`, `05-video-studio-phone-sheet.png`.

### 3. Add LoRA sheet (`SimpleSheet` + new body)

Simple's existing chrome, unchanged: bottom sheet on phone (drag handle, `max-height:76%`, `border-radius: var(--r-xl) var(--r-xl) 0 0`, `padding: 8px 18px 26px`, `su-sheetup`), centered 460px card on tablet/desktop (`max-width: calc(100% - 48px)`, `max-height:78%`, `padding: 20px 22px 24px`, `border-radius: 18px`, `su-pop`). Backdrop `rgba(15, 22, 34, 0.42)`, click closes; Escape closes; focus moves into the panel.

Screenshots: `06-sheet-populated.png`, `07-sheet-empty.png`, `08-sheet-import-uploading.png`, `09-sheet-import-queued.png`, `10-sheet-phone-bottom-sheet.png`.

---

## Components (exact specs)

All values below are existing tokens. `--control-h` is 38px.

### A. LoRA field header

```
display: flex; align-items: baseline; justify-content: space-between; gap: 10px;
```
- Left: `<label>` — 11px / 600 / `--text-muted`, text `LoRAs`. (Matches `.su-field > label`.)
- Right: status `<span>` — 11px / 400 / `--text-faint`, right-aligned. Copy is lifted verbatim from `LoraPickerSection`:
  - `n selected · installed and compatible` when any are selected
  - `Installed and compatible` when none and a model is resolved
  - `Choose a model` when no model is resolved

The field wrapper is `display: grid; gap: 7px`.

### B. Selected LoRA slot (`.su-lora-slot`)

One per selected LoRA, stacked in a `display:grid; gap:7px` list.

```
padding: 10px;
border: 1px solid var(--border);
border-radius: var(--r-sm);      /* 8px */
background: var(--surface);
display: grid; gap: 8px;
```

**Head row** — `display:flex; align-items:flex-start; gap:8px`
- Text block (`flex:1; min-width:0`):
  - `<strong>` name — 12.5px / 600 / `--text`, single line, ellipsis.
  - `<small>` meta — 10.5px / 400 / `--text-faint`, `margin-top:1px`, format `` `${scope} · ${family}` `` (e.g. `global · z-image`) — same `loraMeta()` helper as `LoraPickerSection`.
- Remove button — 24×24, `display:grid; place-items:center`, `border:1px solid var(--border)`, `border-radius: var(--r-xs)`, `background: var(--surface)`, glyph `×` 14px, color `--text-faint`.
  - Hover: `color: color-mix(in oklch, var(--danger) 75%, var(--text))`, `border-color: color-mix(in oklch, var(--danger) 45%, var(--border))`.
  - `aria-label="Remove {name}"`, `title="Remove"`.

**Trigger-keyword chips** — rendered only when `lora.triggerWords?.length`. `display:flex; flex-wrap:wrap; align-items:center; gap:5px`.
- Chip: `padding: 2px 8px`, `border: 1px solid var(--border)`, `border-radius: var(--r-pill)`, `background: var(--surface-2)`, `color: var(--text-muted)`, `font-family: var(--font-mono)`, 10.5px / 600.
- Hover: `border-color: var(--accent)`, `background: var(--accent-soft)`, `color: var(--accent-strong)`.
- **Chips are buttons.** Clicking one appends the keyword to the prompt (`", " + word`, skipped if the prompt already contains it, case-insensitive) — this is the whole reason keywords are surfaced: a trigger word does nothing unless it's in the prompt. `title="Add to prompt"`.
- Trailing hint `<span>` `tap to add to prompt` — 10px / `--text-faint`. On desktop, reword to `click to add to prompt` if you prefer pointer-accurate copy.
- Notes (`lora.notes`) are intentionally **not** shown in Simple (they are in `LoraKeywordSummary` for Advanced).

**Weight row** — `display:grid; gap:3px`
- Label line: `display:flex; align-items:baseline; justify-content:space-between; gap:8px`
  - `Weight` — 10px / 700 / `letter-spacing: 0.06em` / uppercase / `--text-faint` (the eyebrow treatment).
  - Value — `var(--font-mono)` 11.5px / 600 / `--text`, `weight.toFixed(2)`.
- `<input type="range">` — full width, `accent-color: var(--accent)`, `min={LORA_WEIGHT_MIN}` (**−2**), `max={LORA_WEIGHT_MAX}` (**2**), `step={LORA_WEIGHT_STEP}` (**0.05**) from `presetUtils.js`. Default value is `loraWeight(lora)` (manifest `defaultWeight`/`weight`, else 0.8, else 1.5 for the `krea-2` family). `aria-label="{name} weight"`.
- The bidirectional −2…2 range is deliberate — slider-style LoRAs run negative; do not clamp to 0…1.

### C. Pending-import slot

Shown while a `lora_import` job the user started from this sheet is still running. Same box as a slot but:
```
border: 1px dashed color-mix(in oklch, var(--accent) 45%, var(--border));
```
- Head: name = the imported filename (mono-ish plain text, 12.5px/600); meta `importing · family detected: z-image` (10.5px `--text-faint`); right pill `Queued` — `padding:2px 9px`, `border-radius: var(--r-pill)`, `background: color-mix(in oklch, var(--warm) 18%, var(--surface))`, `color: color-mix(in oklch, var(--warm) 70%, var(--text))`, 11px/600 (this is `.su-job-badge--running`, reused).
- Progress bar — reuse `.su-bar` + `.su-bar--indeterminate`: 6px tall, `border-radius: var(--r-pill)`, track `--surface-2`, fill `--accent` at `width:40%` with the existing `su-sweep` keyframe (1.1s `--ease-out` infinite). Use the indeterminate sweep until the job reports a percentage, then switch to a real width — matching `SimpleJobCard`.
- Footer copy: `Becomes selectable here when the Queue completes.` (11px, `--text-muted`).
- Drive this from the same job feed the Queue uses; do not invent local progress state. The Queue nav badge increments as usual.

### D. Add LoRA row

```
display: flex; align-items: center; gap: 8px;
height: var(--control-h);
padding: 0 11px;
border: 1px dashed var(--border-strong);
border-radius: var(--r-sm);
background: var(--surface);
color: var(--accent-strong);
font-size: 12.5px; font-weight: 600;
```
- `Icon.Plus` at 15px, label `Add LoRA`, then a right-aligned count `· {n} available` (11px / 500 / `--text-faint`, `margin-left:auto`) — same `data-count` information the advanced `.lora-add` shows.
- Hover: `border-color: var(--accent)`, `background: var(--accent-soft)`.
- **Always enabled**, even at 0 available (sc-15373): the sheet is where the reason and the fix live.
- At the per-run cap, a line below reads `Limit reached — {max} LoRAs per run.` (11px, `--text-muted`). The prototype renders **5**; the code constant today is `MAX_USER_JOB_LORAS = 4` (`MAX_JOB_LORAS_TOTAL = 5`, one slot reserved for an auto-applied builtin such as Krea's managed `image_edit` LoRA). **Use the constant, not the number in the mock** — the mock's 5 was a review request, and Simple's edit mode auto-applies that builtin, so 4 remains correct.

### E. Sheet body — picker list

- Title `<h2>` `Add LoRA` — 16px / 700, `margin: 0 0 14px` (`.su-sheet-title`).
- Rows (`display:grid; gap:4px`), each a full-width button:
  ```
  display: flex; align-items: center; gap: 10px;
  padding: 11px 12px; border: 0; border-radius: var(--r-sm);
  background: transparent; text-align: left;
  ```
  Hover `background: var(--surface-hover)`. (This is `.su-option-row` with a trailing action instead of a tick.)
  - `<strong>` name 14px/600, `<small>` meta 11px `--text-faint` (`scope · family`).
  - Right: `Add` — 12px / 700 / `--accent-strong`; becomes `Limit reached` and the row is disabled when at the cap (mirrors `.lora-pick-row` / `.lora-pick-add`).
- Selecting a row adds the LoRA and closes the sheet (`.lora-pick-row` does the same).
- Eligibility is **not** re-implemented: filter with `loraMatchesModel(lora, selectedModel)`, exclude `installState === "missing"` and `presetManaged`, and never offer a family-less LoRA (`loraHasResolvableFamily`).

### F. Sheet body — empty state

Replaces the list with a single paragraph, 12.5px / 1.5 / `--text-muted`, using `LoraPickerSection`'s existing `loraEmptyMessage` strings verbatim:
- `No installed LoRAs match {model name}.`
- `No installed compatible LoRAs. Imports appear after the Queue completes.` (when a compatible LoRA exists but is still downloading)
- `No model selected`

When empty, the import section starts **expanded** — the reason and the fix are in the same place (sc-15373).

### G. Sheet body — import

Collapsed by default behind one row, separated by `border-top: 1px solid var(--border)` with `margin-top:12px; padding-top:8px`:
- Trigger row: 26×26 `Icon.Plus` badge (`border-radius:7px`, `background: var(--accent-soft)`, `color: var(--accent-strong)` — the `.su-guide-num` treatment), `<strong>Import a LoRA</strong>` 13px/600, `<small>From a URL or a file — family and scope are detected</small>` 11px `--text-muted`, trailing chevron (`Icon.ChevDown`, flips to up when open), 14px `--text-faint`.

Expanded panel:
```
margin-top: 6px; padding: 13px;
border: 1px solid var(--border); border-radius: var(--r-md);
background: var(--surface-2);
display: grid; gap: 10px;
```
- **Source segment** — the `.su-switch` segmented control (2 buttons, `URL` / `Upload`), full width, `padding:3px`, active = `background: var(--accent-soft); color: var(--accent-strong); font-weight:600`. Default **Upload**, matching Model Manager and `StudioLoraImportPanel` ("most LoRAs are a file the user already has").
- **Upload mode** — label `LoRA file`; a `Choose` pseudo-button (`height: var(--control-h)`, `padding: 0 14px`, bordered, 12.5px/600) wrapping a hidden `<input type="file" accept=".safetensors,.ckpt,.pt,.bin">`, plus the selected filename in `var(--font-mono)` 11.5px `--text-faint`, or `No file selected`. Re-key the input after a successful import so picking the same file twice still fires `change`.
- **URL mode** — label `Source URL`, `<input placeholder="https://...">`, `.su-input` styling (`height: var(--control-h)`, `padding: 0 11px`, `--r-sm`, 13px).
- **Name** — `<input placeholder="Optional">`, same styling.
- **Trigger keywords** — reuse `KeywordTagEditor`'s behavior (commit on Enter or comma; Backspace on an empty draft removes the last chip) in Simple dress: a bordered box (`min-height: var(--control-h)`, `padding: 6px 8px`, `--r-sm`, `background: var(--surface)`) holding mono chips with a `×` and a borderless input, placeholder `e.g. sksStyle — press Enter or comma to add`.
- **Scope and Family are not exposed.** Send no `family` (the importer auto-detects and reports it back as `job.payload.manifestEntry.family`) and default `scope` to `project` when a project is open, else `global` — the same default `StudioLoraImportPanel` uses.
- **Submit** — `Queue import`: full-width accent button, `min-height:38px`, `--r-sm`, `background: var(--accent)`, `color: var(--accent-fg)`, 13px/600. Disabled when no source is chosen or an import is in flight.
- Helper copy, always visible, 11px / 1.5 / `--text-muted`: `Imported LoRAs land in your library and become selectable here once the import job completes — no trip to Model Manager.`

**Import states**
- *Uploading* — button reads `Uploading` at `opacity:.85`, followed by the indeterminate `.su-bar` and `Uploading LoRA file before queueing import.` (11.5px `--text-muted`).
- *Queued* — success line `LoRA import queued for {loraId}. Detected family: {normalizeLoraFamily(family)}.` in `color-mix(in oklch, var(--success) 74%, var(--text))`, 11.5px/600. Clear the form (source, name, keywords) and leave the sheet open. This is `StudioLoraImportPanel`'s message contract, unchanged.
- *Error* — show `err.message` in `--danger`; the import surface never swallows a reason.

The sheet must render as a `<div role="group">`, not a `<form>`, if it ends up nested in a form (`StudioLoraImportPanel`'s note about nested forms applies).

---

## Interactions & behavior

| Trigger | Result |
| --- | --- |
| Click **Add LoRA** | Opens the sheet via `useSimpleUi().openSheet` — bottom sheet on phone, centered card otherwise |
| Click a picker row | Adds the LoRA at `loraWeight(lora)` and closes the sheet |
| Click a keyword chip | Appends the keyword to the prompt (no duplicate) |
| Drag a weight slider | Updates that LoRA's weight override; the mono value updates live |
| Click a slot's `×` | Removes that LoRA (and its weight override) |
| Toggle **Import a LoRA** | Expands/collapses the import panel; chevron flips |
| **Queue import** | Uploads (file mode) then creates the `lora_import` job via `createLoraImportJob`; shows the pending slot in the stack and the Queue badge |
| Import job completes | Pending slot disappears; the LoRA appears in the picker list (it does **not** auto-select) |
| Model change | Drop selections that no longer match the new family — same prune as `useGenerationStudio`, guarded so an unresolved catalog can't strip a restored selection |
| Navigate away and back | Selections and weights persist with the rest of the studio's snapshot |

**Motion** — only what already exists: `su-pop` 0.2s and `su-sheetup` `--t-med` for the sheet, `su-fadein` 0.18s for the backdrop, `su-sweep` 1.1s for the indeterminate bar, `--t-fast` on hovers. All are already inside the `prefers-reduced-motion` block in `simple.css`.

**Responsive** — nothing about the LoRA block changes per band; it inherits the settings bar. The bands (`breakpoint.js`, measured from the shell's own mount, not `window`): phone < 680 (hamburger + drawer + bottom sheets, settings row collapses to one column), tablet 680–1023 (sidebar, 680px content), desktop ≥ 1024 (sidebar, 900px content). Slots are full-width in every band, so a 4-LoRA stack stays legible at 390px.

## State management

New state in each Simple studio (mirror `useGenerationStudio`'s LoRA bundle rather than inventing a second contract):

```
selectedLoraIds: string[]           // selection order
loraWeights: Record<string, number> // sparse overrides; fall back to loraWeight(lora)
sheetOpen: boolean                  // owned by SimpleUiContext.openSheet
importOpen: boolean                 // sheet-local
importForm: { mode: "file" | "url", file, sourceUrl, name, triggerKeywords[] }
importing: boolean, message: { tone, text }
```

Derived: `compatibleLoras`, `availableLoras` (compatible minus selected), `userSelectedLoraCount`, `atLimit`, `loraEmptyMessage`. Include `selectedLoraIds` + `loraWeights` in the studio's persisted snapshot alongside prompt/model/resolution.

Data comes from `useAppContext()`: `loras`, `createLoraImportJob`, `activeProject`, plus the existing job feed. No new endpoint — `POST` the same import payload Model Manager sends, and `serializeLora(lora, { weight })` into the request's `loras` array (replacing `loras: []` in `simpleJobs.js`, in both `IMAGE_DEFAULTS` and `buildSimpleVideoRequest`). Simple's edit mode keeps auto-applying the managed `image_edit` LoRA on top; that one is not a picker entry and must still count toward `MAX_JOB_LORAS_TOTAL`.

## Design tokens used

Colors — `--bg`, `--bg-2`, `--surface`, `--surface-2`, `--surface-hover`, `--border`, `--border-strong`, `--text`, `--text-muted`, `--text-faint`, `--accent`, `--accent-strong`, `--accent-soft`, `--accent-fg`, `--warm`, `--success`, `--danger`, `--wordmark-strong`. Backdrop `rgba(15, 22, 34, 0.42)`. Nothing new.

Radii — `--r-xs` 6, `--r-sm` 8, `--r-md` 12, `--r-lg` 16, `--r-xl` 22, `--r-pill` 999; the desktop sheet card keeps its literal `18px`.

Type — `--font-ui` (Plus Jakarta Sans) for UI, `--font-mono` (JetBrains Mono) for weights, families and filenames. Sizes used here: 16/700 sheet title, 14/600 picker row name, 13/600 import row, 12.5/600 slot name and controls, 11.5/600 mono weight value, 11/600 field label, 11/400 status and helper copy, 10.5/400 slot meta, 10/700 uppercase `WEIGHT` eyebrow.

Density — `--control-h` 38 (selects, inputs, Add LoRA row), 34 chips, 54 Generate; settings-bar padding 12, slot padding 10, gaps 7/8/10/11/14.

Motion — `--ease-out`, `--t-fast` 120ms, `--t-med` 220ms.

Numeric constants — `LORA_WEIGHT_MIN` −2, `LORA_WEIGHT_MAX` 2, `LORA_WEIGHT_STEP` 0.05, `MAX_USER_JOB_LORAS` 4, `MAX_JOB_LORAS_TOTAL` 5.

## Assets

- Icons: the existing `Icon` set (`apps/web/src/components/Icons.jsx`) — `Plus`, `ChevDown`, `Info`, `Image`, `Video`, `Audio`, `Library`, `Model`, `Queue`, `Sliders`, `Book`, `Menu`, `Sparkle`. The prototype inlines the same 24×24 / 1.7px `d` paths; use the component. No new glyph is needed.
- Brand mark: the design-system `Logo` component (`assets/logo.svg`) — not redrawn.
- Style-strip thumbnails: the existing `/style-thumbs/{groupId}.png` convention with the diagonal checkerboard fallback. Group names in the mock are the real eight from `data/styles.json`.
- LoRA names, filenames and keywords in the mock (`Cinematic Grain 35mm`, `analog_35mm.safetensors`, `cinegrain`, …) are **placeholder content**, not a catalog to ship.

## Files

In `design/`:
- `Simple UI LoRA.dc.html` — the canvas that lays out every frame (three sections: image studio, video studio, sheet states).
- `SimpleStudio.dc.html` — the Simple shell + studio screen, including the LoRA row. Props: `bp`, `studio`, `theme`, `accent`, `sheet`, `selectedCount`, `maxLoras`, `pending`.
- `LoraSheet.dc.html` — the Add LoRA sheet body (picker list, empty state, collapsed import, import states).

Open `Simple UI LoRA.dc.html` in a browser to interact with it: add/remove LoRAs, drag weights, open the sheet, expand the import, queue an import.

`screenshots/` — ten captures, listed per screen above.

`github.md` — the source association plus a screen → repo-file map of everything the recreation was read from.

## Source files this was built from

Shell and studios: `simple/SimpleShell.jsx`, `simple/SimpleImageStudio.jsx`, `simple/SimpleVideoStudio.jsx`, `simple/studioParts.jsx`, `simple/SimpleSheet.jsx`, `simple/SimpleModeSwitch.jsx`, `simple/simple.css`, `simple/breakpoint.js`, `simple/modelDefaults.js`, `simple/simpleJobs.js`.

LoRA behavior: `components/generationStudio.jsx` (`LoraPickerSection`, `useGenerationStudio`), `components/StudioLoraImportPanel.jsx`, `components/LoraPickerField.jsx`, `components/LoraKeywordSummary.jsx`, `components/KeywordTagEditor.jsx`, `screens/ModelManagerScreen.jsx` (`importLora`), `presetUtils.js`, `hooks/useModelsAndLoras.js`.

Icons and styling: `components/Icons.jsx`, `apps/web/src/styles.css`.
