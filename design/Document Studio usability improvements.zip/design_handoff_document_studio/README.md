# Handoff: Document Studio usability redesign (direction 1a — "Guided Compose")

## Overview
A redesign of SceneWorks' **Document Studio** (`apps/web/src/screens/DocumentStudio.jsx`), the screen that generates interleaved text-and-image documents. The goals:

1. Turn the flat "Reference images (optional)" multi-select into an ordered, reorderable **storyboard** of frames with captions.
2. Move the **System prompt** (and **GPU**) out of the always-visible form into the standard **Advanced** disclosure, matching the other studios.
3. Add real **guidance** for writing an interleaved-document brief: optional broad quick-start scaffolds, clickable starter chips, and a "writing a good brief" tips card.
4. Add a **Reference guidance** slider (image CFG) to the storyboard, plus a plain-language explainer of what reference frames actually do.

## About the Design Files
The file in this bundle (`Document Studio.dc.html`) is a **design reference created in HTML** — a prototype showing the intended look and behavior. It is **not production code to copy directly**. The task is to **recreate this design inside the existing SceneWorks web app** (React + Vite, in `apps/web/`) using its established components, CSS classes, and design tokens — not to ship the HTML.

The prototype was built as a single self-contained HTML file with inline styles that mirror the app's real CSS-variable tokens. In the real codebase you should instead reuse the existing classes and components listed under **Reuse from the existing codebase** below.

## Fidelity
**High-fidelity.** Final layout, colors, typography, spacing, and interactions. Colors/spacing are expressed with the app's existing design tokens (`var(--accent)`, `var(--surface)`, etc. from `apps/web/src/styles.css`) — recreate pixel-for-pixel using those same tokens and the existing `.work-panel` / `.advanced-section` / `.segmented-control` chrome. The prototype renders on the **dark** theme, but all values are token-based so it themes automatically; do not hardcode the dark hex values.

## Reuse from the existing codebase
- **`WorkPanel`** (`components/WorkPanel.jsx`) — the elevated card with the accent top-rule. Keep `eyebrow="Compose a document"` and update the `hint` (see copy below).
- **`AdvancedSection`** (`components/AdvancedSection.jsx`) — use verbatim for the new Advanced disclosure. `label="Advanced"`, `hint="GPU · system prompt"`, controlled via local `open`/`onToggle` state. Put the GPU `<select>` and the System-prompt `<textarea>` (+ "Reset to default") inside it.
- **`ModelAvailabilityGate`** — unchanged; still wraps the screen.
- **`WorkerProgressCard`** / `.local-job-stack` / `.local-job-group` / `DocumentView` — results zone is unchanged.
- Design tokens, `.field` / `.field-row`, `.settings-bar`, `.segmented-control`, `.primary-action`, `.secondary-action` — all already in `styles.css`.

## Screens / Views

### Document Studio — compose form (the only screen)
- **Purpose**: The user describes a document, optionally storyboards reference frames, sets render settings, and composes an interleaved document.
- **Layout**: Standard Page-Frame — one `WorkPanel` (Purpose zone) above the bare results zone. Inside the panel, top-to-bottom, `gap: 16px`:
  1. Panel head (eyebrow + hint).
  2. **Quick-starts row** (was "Document type").
  3. **Prompt + Tips** — a 2-column grid `grid-template-columns: minmax(0,1.55fr) minmax(0,1fr); gap:14px; align-items:start`.
  4. **Starters row** — full-width, its own row (do NOT nest under the prompt column).
  5. **Storyboard** block.
  6. **Settings strip** (Model / Size / Max images).
  7. **Advanced** disclosure (GPU + System prompt).
  8. Primary action "Compose document".

#### Components

**Panel head**
- Eyebrow: "Compose a document" (`.eyebrow`, `--accent-strong`).
- Hint (`--text-muted`, 12.5px): "Describe the document you want — a guide, a poster, an ad page, an infographic, a comic, anything — then storyboard the shots. The model interleaves prose with the images it generates."

**Quick-starts row (replaces the 3 hard document types)**
- Label (12px/600, `--text-muted`): "Start from an example" + faint suffix "· optional — a starting scaffold, not a limit. Describe anything below."
- A single wrapping row of pill chips (`border-radius: var(--r-pill)`, `padding: 6px 12px`, 12.5px, 13px leading icon): **Blank** (dashed border), **Storyboard** (selected — `border: 1px solid var(--accent)`, `background: var(--accent-soft)`, weight 600), Illustrated guide, Poster, Ad / landing page, Infographic / chart, Tutorial, Comic strip, Lookbook — followed by muted text "…or anything you describe".
- Behavior: purely a **scaffold seeder**. Selecting a chip prefills the prompt textarea with a starter template for that kind and can set sensible defaults (size/max images); it must NOT constrain what the user can generate. This list is illustrative, not exhaustive — keep it easy to extend. "Blank" clears the scaffold.

**Prompt (left column of the 2-col grid)**
- Label: "What should it cover?"
- `<textarea>` min-height 132px, `--surface`/`--surface-2` bg, `--border`, `var(--r-sm)`, 13.5px/1.55.

**Tips card (right column)**
- Surface-2 card, `var(--r-md)`, `padding:13px 15px`, `border:1px solid var(--border)`.
- Uppercase eyebrow with an info icon: "Writing a good brief".
- Numbered list (12px/1.45, accent-strong numerals):
  1. Name each beat you want as an image — the model makes one per beat.
  2. Give an order: "open on…", "then…", "finally…".
  3. State one consistent style so the shots match.
  4. Keep people/props named so they recur.

**Starters row (full-width)**
- `display:flex; flex-wrap:wrap; gap:7px; align-items:center`.
- Leading label "Starters" (11px/600, `--text-faint`), then dashed pill buttons (`+` prefix): "Set the scene", "Add a beat", "Name a character", "Describe the mood", "Add a caption line". Clicking inserts that snippet into the prompt.

**Storyboard block** (surface-2 card, `var(--r-md)`, padding 14px, `gap:10px`)
- Header: "Storyboard" + faint "· optional reference frames, drag to reorder", right-aligned frame count.
- **Explainer callout** (surface card, eye icon): **"The model looks at these frames — it doesn't copy their style."** (bold, `--text`) + "It reads them the way you would to describe a picture, then your prompt decides what to do with them." Below: "Your prompt might say:" and four illustrative pills — "keep this character", "edit what's shown", "compose from these", "illustrate my text".
- **Filmstrip**: horizontal scroll (`display:flex; gap:12px; overflow-x:auto`). Each frame = 168px column: a 104px thumbnail (drop target / generated image; number badge top-left `--accent`/`--accent-fg`; drag handle "⠿" top-right) + a caption `<input>` (32px, 12px). Trailing dashed **"Add frame"** tile (120px). Frames are **ordered and drag-reorderable**; caption is per-frame.
- **Reference guidance slider** (below a hairline):
  - Label "Reference guidance" + faint "· how hard the model leans on the frames"; right-aligned mono value bubble in an `--accent-soft` pill.
  - `<input type="range" min="0.5" max="2.5" step="0.1" value="1.0">`, `accent-color: var(--accent)`.
  - End labels: "Follow the prompt" (left) / "Stay close to references" (right).
  - Hint: "Sets the image guidance (CFG) for the references. Higher holds tighter to what the frames show; lower gives your prompt more room."

**Settings strip** (`--surface-2`, `var(--r-md)`, padding 12px 14px, flex-end wrap)
- **Model** (`flex:2 1 200px`), **Size** (`flex:1 1 140px`), **Max images** number (`flex:0 1 110px`). Uppercase micro-labels (10.5px/700, `--text-faint`), 36px controls. GPU is NOT here anymore.

**Advanced disclosure** — the `AdvancedSection` component. Collapsed by default (header-only). Body contains:
- **GPU** `<select>` (max-width 220px).
- **System prompt**: label + small helper "Steers the model's think / no-think composition. Prefilled with the default — edit to change behavior." + a mono `<textarea>` (min-height 120px) seeded with `DEFAULT_INTERLEAVE_SYSTEM_MESSAGE`, plus the existing "Reset to default" `.secondary-action` when edited.

**Primary action**: `.primary-action` "Compose document" (min-height 44px), disabled until a prompt exists.

## Interactions & Behavior
- **Quick-start chip** → seeds a prompt scaffold (+ optional default size/max images); never restricts output. Single-select; "Blank" resets.
- **Starter chip** → appends/inserts a snippet into the prompt textarea at the caret.
- **Storyboard**: add / remove / drag-reorder frames; each frame holds an optional reference image (drop or pick from assets) and a caption. Order is significant and must be preserved on submit.
- **Reference guidance slider** → live value readout; drives the image-CFG value on submit (see State/Submit).
- **Advanced** header → toggles the disclosure open/closed (caret rotates, "Show"/"Hide" label).
- **Submit** → existing `createInterleaveJob(...)` then `rememberLocalGenerationJob("document", job)`; run streams into the results stack below.

## State Management
Extends the existing `DocumentStudio` state:
- `prompt` (string) — existing.
- `quickStart` (string id | null) — selected scaffold; drives prefill only.
- `model`, `resolution`, `maxImages` — existing (visible settings).
- `storyboardFrames` — **ordered array** of `{ id, assetId | null, caption }`. Replaces the flat `sourceAssetIds`; on submit derive `sourceAssetIds = storyboardFrames.map(f => f.assetId).filter(Boolean)` in frame order (plus send captions if the worker can consume them).
- `referenceGuidance` (number, default **1.0**, range **0.5–2.5**, step 0.1).
- `gpu` (requestedGpu) — existing, now inside Advanced.
- `systemMessage` — existing, now inside Advanced.
- `advancedOpen` (bool) — controls `AdvancedSection`.

**Submit mapping**: send `referenceGuidance` as the SenseNova image-guidance CFG — i.e. `advanced.imageGuidanceScale` (the model's `ui.variationStrength` "Reference strength" lever in `constants.js`). ⚠️ The product decision here is **range 0.5–2.5, default 1.0**, which intentionally overrides the catalog's current `variationStrength` default (`0.5–4.0`, default `1.5`) for `sensenova_u1_8b`. Align the control bounds to 0.5–2.5/1.0 (and, if desired, update the model's `ui.variationStrength` accordingly). System prompt continues to send only when edited (blank/default lets the worker use its own default).

## Design Tokens (all already defined in `apps/web/src/styles.css`)
- Accent: `--accent`, `--accent-strong`, `--accent-soft`, `--accent-fg`.
- Surfaces: `--bg`, `--bg-2`, `--surface`, `--surface-2`, `--surface-hover`.
- Lines/text: `--border`, `--border-strong`, `--text`, `--text-muted`, `--text-faint`.
- Radius: `--r-sm` 8, `--r-md` 12, `--r-lg` 16, `--r-pill` 999.
- Type: `--font-ui` (Plus Jakarta Sans), `--font-mono` (JetBrains Mono).
- Shadows: `--shadow-sm/md/lg`. Control height baseline `--control-h` (38px).

## Assets
No new assets. Icons are inline stroke SVGs matching the app's `Icon` set (`components/Icons.jsx`) — reuse `Icon.Wand` (Document), plus book/poster/chart/grid glyphs at 1.7 stroke, 24×24 viewBox. Brand mark is the existing `Logo` component. The chrome (sidebar/topbar) in the prototype is only for context — it already exists in `App.jsx` and should not be reimplemented.

## Files
- `Document Studio.dc.html` — the high-fidelity design reference (this bundle).
- Target for implementation: `apps/web/src/screens/DocumentStudio.jsx` (+ reuse `components/AdvancedSection.jsx`, `components/WorkPanel.jsx`, `components/AssetPicker.jsx`, `components/DocumentView.jsx`, tokens in `styles.css`).
