# Handoff: SceneWorks Simple UI

## Overview
A **Simple UI** alternative to SceneWorks' full desktop workspace — a calmer, reduced-surface experience for users who don't want every advanced control at once. It is **mobile-first but fully responsive**: phones are always served this UI; on tablet/desktop it becomes a persistent-sidebar app. It covers four studios (Image, Video, Audio, Assets) plus the management screens (Model Manager, Queue, Settings, Licenses), and keeps a Simple ⇄ Advanced switch so users can jump to the full workspace.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing the intended look and behavior. They are **not production code to copy directly**. The task is to **recreate them inside the existing SceneWorks web app** (`apps/web`, React + Vite) using its established patterns: the same `styles.css` design tokens, the `Icon` set in `apps/web/src/components/Icons.jsx`, the `Logo` component, the existing screen/hook architecture (`apps/web/src/screens/*`, `apps/web/src/hooks/*`), and the model/style catalogs already in the codebase.

The prototype is a self-contained component system (a small React-like runtime). Treat its logic as a **behavioral spec**, and its markup/inline styles as a **visual spec** — re-express both with real SceneWorks components, real API/hooks, and CSS classes from `styles.css` rather than inline styles.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, radii, and interactions. Recreate pixel-perfectly using the codebase's existing tokens and components. All colors below map to CSS custom properties already defined in `apps/web/src/styles.css` — use those variables, do not hardcode new hex values.

## Architecture / Shell

The app is one responsive shell with three breakpoints driven by the **container** width (measure the mount, not `window` — it must work embedded):
- **phone** `< 680px` — top bar with a hamburger; nav is an overlay **drawer** (left, 288px, slides in over a scrim). Bottom-sheet selectors.
- **tablet** `680–1023px` — **persistent left sidebar** (244px), no hamburger; content column capped at `max-width: 680px`, centered. Selectors are centered modal dialogs.
- **desktop** `≥ 1024px` — persistent sidebar; content column capped at `max-width: 900px`, centered.

Shell layout: `display:flex` row of `[sidebar][main]`. `main` is a flex column of `[top bar][scrolling body]`. On phone the sidebar is `position:absolute` overlay instead of an in-flow column.

**Top bar** (`.topbar` equivalent): hamburger (phone only) + screen title (17–18px/700) + one-line subtitle (12.5px, `--text-muted`). The Simple/Advanced switch is **only in the sidebar** (see below), not the top bar.

**Sidebar** (mirror the real app's `.sidebar`/`.nav-item`): brand (Logo mark + "SceneWorks" / "Simple"), a "STUDIOS" group (Image, Video, Audio, Assets) and a "MANAGE" group (Model Manager, Queue [badge "2"], Settings, Licenses). Active item = `--surface` bg + `--shadow-sm` + a 3px `--accent` left rule (matches `.nav-item.active`). Sidebar footer holds the **Simple ⇄ Advanced** segmented switch (Simple active).

## Screens / Views

### Image Studio (`ImageStudio.jsx`)
- **Purpose:** text-to-image and edit, with variations.
- **Layout:** vertical stack inside the centered content column: mode tabs → prompt → tool tiles → settings bar → style strip → Generate → results.
- **Components:**
  - **Mode tabs** — underline tabs "Text" / "Edit" (matches `.mode-tab`: 14px, active 700 + 2px `--accent` underline).
  - **Prompt** — label row with a right-aligned **"Prompt guide"** pill (opens the guide overlay — this replaced an earlier "Refine" pill). `<textarea>`, min-height 104px, standard input chrome.
  - **Tool tiles** — 2-col grid: **Reference** (armed state shows "SET" badge + thumbnail + filename; tap toggles attach) and **Refine** (opens inline refine panel — the AI-rewrite of the prompt). Active tile = `--accent` border + `--accent-soft` bg (matches `.prompt-tool`).
  - **Settings bar** (`.settings-bar`, `--surface-2`): Model select (opens sheet), Resolution select (opens sheet), Variations segmented chips [1,2,4,6] (selected = accent).
  - **Style strip** — horizontal scroll of 66px style thumbnails: None, Anime, Cartoon, Comics, Photographic, Painterly, 3D / CGI, Concept Art, Cinematic. Selected = 2px accent border. (Back this with the real `styleCatalog` groups.)
  - **Generate** — full-width primary button, **min-height 54px**, `--accent` bg, shows spinner + "Generating…" while busy. Label reflects count ("Generate 4 images").
  - **Results** — grid (1 col for 1 var, 2 cols normally, 3 cols for 6 on desktop) of square tiles; each tile has favorite (top-right) and download (bottom-right) circular overlay buttons.
- **Models shown:** Z-Image, Qwen-Image, FLUX.1 [schnell], FLUX.1 [dev], FLUX.2 [klein] 9B, Krea 2 (Turbo), Ideogram 4, SDXL, Stable Diffusion 3.5 Large. **Sizes:** 1:1 1024², 16:9 1344×768, 9:16 768×1344, 3:4 896×1152, 4:3 1152×896, 3:2 1216×832.

### Video Studio (`VideoStudio.jsx`)
- **Purpose:** text-to-video and image-to-video.
- Same pattern as Image. Tabs "Text → Video" / "Image → Video". Prompt + Prompt-guide pill + Refine (inline). One full-width **Reference image** tile (hint changes: "Optional start frame" vs "Required for Image → Video"). Settings bar: Model, Resolution, **Duration** chips [3s,5s,8s,10s]. Style strip. Generate ("Generate video" → "Rendering…"). Result = single 16:9 tile with a play button.
- **Models:** LTX-2.3, Wan 2.2 (TI2V-5B), Wan 2.2 (T2V-14B), Stable Video Diffusion, SCAIL-2, Bernini. **Sizes:** 16:9 720p, 9:16 720p, 1:1 720p, 16:9 480p.

### Audio Studio (`AudioStudio.jsx`)
- **Purpose:** music / speech / SFX generation. **Note: this studio is unfinished in the product** — treat as a preview; the design shows a warning banner ("Audio Studio is a preview — the models and controls will change as it lands"). Keep it, refine later.
- Segmented mode switch Music / Speech / SFX. Prompt (labeled "Script" in Speech mode). Settings: Model select, **Voice** select (Speech mode only), Duration chips [4s,8s,15s,30s]. Generate → result card with a play button + waveform + timecode.

### Assets (`LibraryScreen.jsx`)
- **Purpose:** browse stills, clips, audio across projects.
- Search field, type filter pills (All / Images / Clips / Audio), responsive thumbnail grid (3 cols phone, 4 tablet, 6 desktop). Video tiles show ▶, audio ♪, favorited tiles show a star. Tap → **full-screen preview** overlay with: large media, **Use as reference** (primary — routes the asset into Image Studio and toasts), Favorite, Download, Delete (danger).

### Model Manager (`ModelManagerScreen.jsx`)
- Tabbed catalog: Image / Video / Utility / LoRAs (underline tabs). Each row: hexagon model glyph, name, meta ("6.1 GB · needs 12 GB"), and a right-aligned **Manage** (installed, neutral) or **Download** (accent) button.

### Queue (`QueueScreen.jsx`)
- Three stat tiles (Running / Queued / Done). Job rows: status dot (running = warm + glow, queued = faint, done = success + glow), title, sub, status badge, and a progress bar (accent for running, success for done; none for queued).

### Settings (`SettingsScreen.jsx`)
- **Appearance:** Theme segmented Light/Dark (**functional** — flips `data-theme`), Accent swatch row (7 accents — **functional**, sets `data-accent`).
- **Generation:** Default quality chips [bf16, Q8, Q4]; "Use Simple UI by default" toggle (on).
- **Service credentials:** host input + Add button (write-only tokens; toasts on save).
- **Device:** Engine (MLX · Apple Silicon), GPU (M3 Max · 48 GB) read-only rows.

### Licenses (`LicensesScreen.jsx`)
- App card: "AGPL-3.0-or-later · © 2026 Michael Trefry & contributors." Model-license rows with a "Commercial OK" (accent) or "Non-commercial" (danger) badge. Use the real `bundledLicenses` data.

## Interactions & Behavior
- **Navigation:** selecting a nav item switches screen and closes the drawer (phone). Screen switch clears any open sheet/preview.
- **Bottom sheet / modal:** Model / Resolution / Duration / Voice open a picker. Phone = bottom sheet (`slide-up`, drag handle, ≤76% height); tablet/desktop = centered modal card (460px, fade+pop). Backdrop click closes.
- **Generate (all studios):** disables re-entry while busy; ~1.5s mock delay → results appear. Wire to the real job queue + `useJobEvents`.
- **Refine:** inline panel with a "Rewrite prompt" button; ~1.1s mock → appends detail to the prompt and closes. Wire to the Anubis-8B refiner.
- **Prompt guide:** overlay (same sheet/modal chrome) with 4 numbered tips + a "Try" example. Close button + backdrop.
- **Toast:** center-bottom pill, `--ink` bg, auto-dismiss ~1.9s. Used for favorite/download/delete/credential/advanced actions.
- **Advanced switch:** in this prototype it only toasts; in production it should route to the full workspace UI.
- **Transitions:** `fadein .18s`, `sheetup .24s`, `drawin .24s`, `pop .2s`, spinner `spin .7s linear`. Use the app's `--ease-out` / `--t-fast` / `--t-med` tokens.

## State Management
Per-studio state objects (prompt, mode, model, size index, variations/duration, style, reference flag, refineOpen/refining, busy, results). Plus app-level: `screen`, `drawer`, `theme`, `accent`, `quality`, `simpleDefault`, `sheet` (which picker), `preview` (asset), `guide` (bool), `toast`, and measured container width → breakpoint. In production, replace the mock timers with the real generation/queue hooks (`useJobEvents`, `useModelsAndLoras`, `usePresets`, `useStudioSettings`) and persist theme/accent as the app already does (pre-paint `theme-init.js`, `data-theme`/`data-accent`).

## Design Tokens
All already defined in `apps/web/src/styles.css` — reuse, don't redefine:
- **Type:** `--font-ui` (Plus Jakarta Sans), `--font-mono` (JetBrains Mono).
- **Accent (hue-driven):** `--accent`, `--accent-strong`, `--accent-soft`, `--accent-fg`; palettes via `[data-accent]` (teal default, + indigo, cobalt, violet, coral, amber, emerald).
- **Surfaces:** `--bg`, `--bg-2`, `--surface`, `--surface-2`, `--surface-hover`; **borders** `--border`, `--border-strong`; **text** `--text`, `--text-muted`, `--text-faint`.
- **Status:** `--success`, `--warm` (queued/running), `--warn` (+ warn-soft), `--danger` / `--danger-soft`. **Brand:** `--ink`, `--teal`, `--paper`, `--mist`.
- **Radii:** `--r-sm 8`, `--r-md 12`, `--r-lg 16`, `--r-pill 999`. **Shadows:** `--shadow-sm/md/lg`.
- Both light and dark ramps are defined; the design uses them via `data-theme`.

## Assets
- **Fonts:** Plus Jakarta Sans + JetBrains Mono (self-hosted woff2, already in `apps/web/public/fonts/`). Copies included here under `fonts/`.
- **Icons:** all glyphs are from the app's existing `Icon` set (`apps/web/src/components/Icons.jsx`) — Image, Video, Audio, Library, Model, Queue, Sliders (settings), Book (licenses), Sparkle, Search, Star, Trash, Play, Plus, Close, ChevDown, etc. Use those, don't redraw.
- **Logo:** the scene-cut mark from `apps/web/src/components/Logo.jsx`.
- Generated media are represented by gradient placeholders (no real imagery in the prototype).

## Files
- `SceneWorks Simple UI.dc.html` — multi-device showcase (desktop + iPad + phone frames), mounts the app three times.
- `Simple UI App.dc.html` — **the actual responsive app** (the real reference; open this full-screen).
- `fonts/` — the two woff2 font files the prototype references.

These `.dc.html` files open directly in a browser. `Simple UI App.dc.html` is the single source of truth for layout and behavior; the showcase just frames it.
