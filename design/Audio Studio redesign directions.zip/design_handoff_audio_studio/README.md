# Handoff: SceneWorks Audio Studio — takes, play deck, and Assets audio viewer

## Overview
The Audio Studio's **"Latest audio"** results zone currently renders nothing but queue-worker
cards (`WorkerProgressCard`), so a creative surface reads like a job monitor. This handoff
replaces it with **run-grouped take cards** — the same grid shape the Image and Video studios
use — plus a **now-playing play deck** that docks above the runs when a take is played.
The same treatment is carried into the **Simple UI** (three responsive bands) and into the
**Simple Assets** page, where an audio asset currently renders as a blank placeholder square
and opens a bare `<audio>` element instead of a real viewer.

Four things to build:

1. **Audio Studio results zone (Advanced)** — run-grouped waveform take cards, a slim
   in-flight progress strip pinned at the top, and a docked play deck. (screen `2a`)
2. **Audio Studio work panel alignment fix (Advanced)** — the settings bar becomes a fixed
   4-column grid with the model capability hint on its own full-width row. (screen `2a`)
3. **Simple UI Audio Studio** — the same takes + deck on the Simple shell at all three
   container bands, with Audio's mode control switched from `su-segmented` to the
   `su-tabs` underline tabs the Image and Video studios already use. (screen `3a`)
4. **Simple UI Assets** — audio assets render the waveform card in the square asset grid and
   open the shared `su-preview` viewer with the deck at full size. (screen `4a`)

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes that show the
intended look and behavior. They are **not production code to copy**. The task is to
**recreate these designs inside the SceneWorks web app** (`apps/web`, React + Vite) using its
existing components, CSS classes and design tokens in `apps/web/src/styles.css` and
`apps/web/src/simple/simple.css`.

Concretely: almost nothing here needs new CSS primitives. The take card is
`.review-card` / `.asset-tile` geometry, the run header is a chip + `.field-hint` row, the
progress strip is a trimmed `.worker-progress-card`, the deck is a new block that reuses
`.review-panel` surfaces and the existing `worker-progress-card__audio*` transport tokens,
and the Simple UI screens reuse `.su-*` classes verbatim. **Do not port the inline styles
from the prototype** — they exist only because the prototype has no stylesheet. Map each one
to the class or token named in this document.

## Fidelity
**High-fidelity.** Every color, size, radius, and font size in the prototype was read out of
the repo's own token block (`apps/web/src/styles.css` `:root` / `[data-theme="dark"]`), so the
mocks are pixel-accurate against the dark theme with the default teal accent
(`--accent-h: 178`). Recreate them pixel-perfectly using the real tokens — never the resolved
literals, so light theme and the six accent palettes keep working.

## Screens / Views

### 1. Audio Studio — `apps/web/src/screens/AudioStudio.jsx` (screen `2a`)
**Purpose.** Generate speech / sound FX / music / cloned-voice clips, audition the takes a run
produced, and act on the good one.

**Layout.** Unchanged page skeleton: `section.page-frame.audio-studio` → `form.studio-shell`
→ `WorkPanel.studio-work-panel` + `div.studio-results`. Page frame gap 18px, work panel
padding `var(--pad-panel)` (20px), 3px accent top rule, `--r-lg` (16px) radius,
`var(--shadow-md)`.

#### 1a. Work panel (existing, with one fix)
- `.prompt-hero-top` → `.mode-tabs.mode-control` with four tabs: **Speech · Sound FX · Music ·
  Voice Clone**. Unchanged, and **no icons** — the real tabs are text only.
- `.prompt-input-row`: prompt textarea (min-height 96px, `--r-md`, `var(--shadow-sm)`) +
  `.prompt-cta` "Generate" (min-width 148px, accent fill, `--accent-fg` label). In the mock the
  ⌘↵ hint moved from the results head to sit under the CTA — optional, cosmetic.
- **Fix (the reported misalignment):** `.settings-bar-row` is a flex row where the Model field
  carries a `.field-hint` (`54 voices · 8 languages · 24 kHz mono · max 120 s`). With
  `align-items: flex-end` that hint makes the Model label sit ~24px higher than VOICE /
  LANGUAGE, and the field also overflows its neighbour. Replace the single flex row with:
  ```
  display: grid;
  grid-template-columns: 2fr 1fr 1fr 1fr;   /* Model · Voice · Language · Length (s) */
  gap: 14px;
  align-items: end;
  ```
  and move the capability hint into a `grid-column: 1 / -1` footer row with
  `border-top: 1px solid var(--border)` and `padding-top: 10px`, sharing that row with the
  Advanced disclosure trigger on the right. All controls stay 36px tall.
  Mode-dependent extra fields (BPM, Key, Length, region start/end, edit strength) keep their
  existing capability gating; they simply become cells in the same grid.

#### 1b. Results zone — "Latest audio"
Head: `h2` "Latest audio" (16px/600) + a muted 12.5px count (`last 12 clips in this project`),
right-aligned link **See all in Assets →** (`--accent-strong`, `Icon.ArrowRight` 14px) which
navigates to the Assets view. Keep the capability-driven `.streaming-badge` where the model
advertises `audio.supportsStreaming`.

**In-flight strip (replaces the full worker card in this surface).** One row per running audio
job, pinned above the run groups, `grid-template-columns: auto minmax(0,1fr) auto`, gap 14px,
padding 12px 14px, `background: var(--surface-2)`, border `var(--border-strong)`, `--r-md`:
- status chip `RENDERING` — `.worker-progress-card__type` styling (accent-soft bg,
  `--accent-strong` text, uppercase 11.5px/600, pill radius)
- title `Speech · Kokoro 82M · 3 takes` (13.5px/600) + message
  `chunk 4 of 9 · ~6 s left · Apple M3 Max` (12px, `--text-muted`)
- a 6px `.progress-track` under the title
- **Cancel** (`.secondary-action`, 30px) and a **Queue** text link
The full `WorkerProgressCard` (job id, GPU meters, attempt counter, hardware pills) stays in
the Queue screen — do not render it here.

**Run groups.** One group per generation run, **newest first**. Group header row, 12px gap,
vertically centered:
- mode chip — uppercase 11px/700, letter-spacing .06em, pill: Speech uses
  `background: var(--accent-soft); color: var(--accent-strong)`; Music uses
  `color-mix(in oklch, var(--warm) 22%, var(--surface))` with `--warm` text; Sound FX and Voice
  Clone follow the same pattern with their own token.
- model name (13.5px/600)
- settings chips — the run's own parameters, mono 11px, 22px tall, padding 0 8px, `--r-xs`,
  `var(--surface-2)` on `var(--border)`: `af_heart`, `en-US`, `12 s`, `seed 4821` for speech;
  `128 BPM`, `C minor`, `instrumental`, `30 s` for music.
- a flexible 1px `var(--border)` rule, then relative time (12px `--text-faint`) and a
  **Run again** link (`Icon.Refresh` 13px + `--accent-strong`) that re-submits the run's payload.

**Take card** (the grid cell). Grid `repeat(auto-fill, minmax(190px, 1fr))`, gap
`var(--gap-3)` — identical to `.review-grid`. Card: `padding: 10px`, `--r-md`,
`background: var(--surface)`, `border: 1px solid var(--border)`, `display: grid; gap: 10px`:
- **Waveform thumbnail** — 118px tall, `--r-sm`, `background: var(--bg-2)`, overflow hidden.
  An SVG bar waveform stretched to the cell width (`preserveAspectRatio="none"`), stroke
  `color-mix(in oklch, var(--accent) 55%, var(--bg-2))`, `stroke-width: 2.6`, round caps.
  Overlays: `Take N` mono 10.5px chip top-left; a 32px round accent **play/pause** button
  bottom-left (`--accent-fg` glyph, `Icon.Play` / `Icon.Pause`); mono 11px duration
  bottom-right. Both chips sit on `color-mix(in oklch, var(--bg-2) 82%, transparent)`.
  While that take is the loaded one, a played-progress band overlays the waveform:
  `background: color-mix(in oklch, var(--accent) 20%, transparent)` with a
  `border-right: 2px solid var(--accent-strong)` playhead, width = `currentTime / duration`.
- **Prompt excerpt** — 13px/1.45, `-webkit-line-clamp: 2`.
- **Meta row** — `Speech · Kokoro 82M` (11.5px `--text-faint`) and mono duration, space-between.
- **Action row** — favourite / download / send-to-timeline / discard, 28px ghost icon buttons
  above a `1px var(--border)` divider; favourite lights `--accent-strong` when set. These map
  to the existing `updateAssetStatus`, download, `sendAssetToVideo` and `deleteAsset` actions.
- The loaded take's card border is `var(--accent)` with
  `box-shadow: 0 0 0 3px color-mix(in oklch, var(--accent) 20%, transparent)`.

**Play deck** (new; the piece the user specifically wants). Rendered **only while a take is
loaded**, docked directly above the first run group, full results width:
`padding: 16px`, `--r-lg`, `background: var(--bg-2)`, `border: 1px solid var(--border-strong)`,
`display: grid; grid-template-columns: minmax(0, 1fr); gap: 14px` — the explicit
`minmax(0, 1fr)` matters: without it the no-wrap transport row makes the grid column
max-content and the deck overflows narrow containers.
- **Head** — mode chip + `Take N`, then the prompt/title (14.5px/600, ellipsis), then, right
  aligned: **Download**, **Send to Video Editor**, **Run again** (32px `.secondary-action`
  buttons; Run again on `--accent-soft`), and a 32px **×** that unloads the deck.
- **Stage** — `padding: 14px 16px 8px`, `--r-md`, `background: var(--bg)` (one step darker than
  the deck), `border: 1px solid var(--border)`. Waveform SVG at 124–150px tall, same stroke
  treatment, with the played band + playhead as above. A mono 10.5px tick row sits under a
  `1px var(--border)` rule showing `0:00 … duration`.
- **Transport** — 32px round secondary skip-back, a 46px accent play/pause with
  `0 8px 22px color-mix(in oklch, var(--accent) 30%, transparent)`, 32px skip-forward, 32px
  loop; then the mono 14px clock `m:ss / m:ss` (elapsed in `--text`, total in `--text-faint`);
  then, right aligned, the run's meta line (12px `--text-muted`, ellipsis).
- Wire it to a real `<audio>` element the way `WorkerProgressCard`'s `AudioTransport` already
  does (native controls off, ref-driven, `onLoadedMetadata` to correct the declared duration).
  Seeking on the stage waveform should map x-offset → `currentTime`.

### 2. Simple UI Audio Studio — `apps/web/src/simple/SimpleAudioStudio.jsx` (screen `3a`)
Same screen order as today: modes → prompt → settings bar → Generate → run status → results.
Changes:
- **Mode control:** replace `.su-segmented` with `.su-tabs` / `.su-tab` (flex, gap 22px, 1px
  bottom rule; tab 14px/500 `--text-muted`, active 700 `--text` with a 2px `--accent`
  underline) so Audio matches `SimpleImageStudio` and `SimpleVideoStudio`. Labels stay
  **Music · Speech · SFX**.
- **Preview notice removed** — the studio is shipping, so drop the `.su-notice` block.
- **Results:** replace the single `.su-audio-result` row with the same deck + take grid, using
  Simple's own vocabulary. Head is `.su-results-head` (`strong` 15px + mono 11px count). Deck
  is a `.su-card`-like block (padding 13px, `--r-md`, `var(--surface)`, border `--border-strong`)
  with the head / stage / transport stack described above at reduced sizes: stage waveform 84px
  desktop, 72px tablet, 58px phone; play button 44px desktop-tablet, 48px phone.
  On phone the deck's Download / Run again move out of the transport row into a
  `.su-preview-row`-style pair of full-width 42px buttons under the clock.
- **Take grid columns:** 3 desktop / 2 tablet / 1 phone, driven by the measured band, not a
  media query (`useContainerWidth` + `breakpointFor`). Cards: 88px waveform, 12.5px title,
  11px meta; phone cards use a 44px play button to meet the touch target.
- Bands come from `apps/web/src/simple/breakpoint.js` unchanged: phone < 680, tablet 680–1023,
  desktop ≥ 1024; content caps none / 680px / 900px.

### 3. Simple UI Assets — `apps/web/src/simple/SimpleAssets.jsx` + `SimplePreview.jsx` (screen `4a`)
**Grid tile.** Audio assets currently render `<span class="su-asset-placeholder"><Icon.Audio/></span>`.
Replace with the waveform card **inside the existing square cell** so rows keep their rhythm
(`--su-asset-cols` = 6 / 4 / 3 from `assetGridColumns`):
- cell is still `aspect-ratio: 1`, `--r-md`, `background: var(--bg-2)`, but becomes
  `display: grid; grid-template-rows: 1fr auto`
- top region: waveform SVG (42px desktop, 38px phone), horizontally padded 6–8px
- bottom bar: `background: var(--surface)`, `border-top: 1px solid var(--border)`, padding
  6–7px, holding a 22–24px accent play button, the display name (11px, ellipsis; hidden on
  phone where the cell is ~108px) and the mono duration
- keep the existing `.su-asset-kind` chip top-left and `.su-asset-fav` star top-right
- the loaded take keeps the `var(--accent)` border

**Viewer.** Clicking an audio tile opens the same `SimplePreview` overlay images and clips use
(`.su-preview`, absolute inset, z-index 80). Only the stage changes: instead of
`<AssetMedia>` rendering a bare `<audio>`, render the deck —
- mode chip + meta line (`Kokoro 82M · af_heart · en-US · 24 kHz mono · 2 min ago`)
- waveform panel: `padding: 16px 18px`, `--r-lg`, `background: var(--bg-2)`, border
  `var(--border)`, waveform 150px desktop / 104px phone, played band + playhead
- transport: 56px accent play/pause + mono 15px clock; on desktop a
  **Send to Video Editor** `.secondary-action` sits at the row's right edge
- stage column is `min(680px, 100%)` desktop, full width phone
- `.su-preview-actions` stay the viewer's own: **Favorite · Download · Delete** in a
  `.su-preview-row`; "Use as reference" remains hidden for audio (as today), and on phone
  **Send to Video Editor** takes the `.su-preview-primary` 48px slot.

## Interactions & Behavior
- **Play a take** → that take becomes the loaded take: the deck mounts above the run groups
  (Simple: above the grid; Assets: it *is* the viewer stage), the card gets the accent ring, and
  playback starts. Pressing the same take's button pauses/resumes; pressing another take's
  button loads that take from 0:00 and plays.
- **Deck ×** unloads the take: deck unmounts, ring clears, audio pauses.
- **Progress** advances the played band and the clock; the band width is
  `currentTime / duration`.
- **Run again** re-submits the group's stored payload (`createAudioJob`) — a new run appears at
  the top of the stack with the in-flight strip.
- **See all in Assets** navigates to the Assets view (`setActiveView("Library")` in the
  workspace, `goTo("assets")` in Simple).
- **In-flight** jobs pin to the top of the same stack and are replaced in place by their run
  group when the assets land (the existing `selectStackedJobs` collapse rule still applies).
- Only one clip plays at a time — loading a new take pauses the previous element.
- Cancel on the strip calls `onCancelJob`; failures keep the existing failed-card treatment.
- Transitions: `var(--t-fast)` (120ms) for hover/border changes, `180ms ease` on the progress
  band (matching `.progress-track span`). No entrance animation on the deck.
- **Responsive:** Advanced screen keeps the auto-fill grid. Simple UI switches columns and deck
  sizes on the measured band only. Every grid/deck container needs
  `grid-template-columns: minmax(0, 1fr)` (or `min-width: 0` on flex children) or the no-wrap
  transport rows overflow at phone width.

## State Management
Per studio screen:
- `loadedTakeId: string | null` — which asset the deck holds (null = no deck)
- `isPlaying: boolean`
- `currentTime: number` — from the `<audio>` element's `timeupdate`, not a timer
- existing state stays as-is: `mode`, `prompt`, `model`, `voice`, `language`,
  `targetDurationSecs`, `bpm`, `musicalKey`, `lyrics`, advanced fields, `audioLocalJobs`
- run grouping is derived, not stored: group `audioLocalJobs` (and the resolved
  `jobAudioResultAssets`) by job id, newest first, and read the header chips off each job's
  own payload — no new API surface
Assets/Simple: `loadedTakeId` lives in the shell beside `preview` so the viewer and the grid
agree on which asset is loaded.

## Design Tokens
All from `apps/web/src/styles.css`; the resolved values are the dark theme with `--accent-h: 178`.

| Token | Dark value | Used for |
| --- | --- | --- |
| `--bg` | `oklch(0.165 0.012 240)` | app canvas, deck stage |
| `--bg-2` | `oklch(0.145 0.012 240)` | sidebar, waveform wells, deck body |
| `--surface` | `oklch(0.205 0.012 240)` | cards, controls |
| `--surface-2` | `oklch(0.235 0.014 240)` | settings bar, chips, progress strip |
| `--surface-hover` | `oklch(0.255 0.014 240)` | hover |
| `--border` | `oklch(0.285 0.014 240)` | hairlines |
| `--border-strong` | `oklch(0.36 0.016 240)` | deck border, focused fields |
| `--text` | `oklch(0.96 0.008 240)` | body |
| `--text-muted` | `oklch(0.72 0.012 240)` | secondary |
| `--text-faint` | `oklch(0.56 0.012 240)` | labels, timestamps |
| `--accent` | `oklch(0.74 0.11 178)` | play buttons, playhead, active tab |
| `--accent-strong` | `oklch(0.82 0.12 178)` | links, chip text on dark |
| `--accent-soft` | `oklch(0.3 0.06 178)` | chips, Run again button |
| `--accent-fg` | `oklch(0.16 0.012 240)` | glyph on accent fill |
| `--warm` | `oklch(0.78 0.11 235)` | Music chip, running dot |
| `--danger` / `--danger-soft` | `oklch(0.62 0.18 25)` / `oklch(0.3 0.06 25)` | Delete |
| `--success` | `oklch(0.62 0.13 155)` | Ready dot |

Spacing `--gap-1..5` = 6 / 10 / 14 / 20 / 28px; `--pad-tile` 14px, `--pad-panel` 20px,
`--control-h` 38px, `--row-h` 40px.
Radii `--r-xs..xl` = 6 / 8 / 12 / 16 / 22px, `--r-pill` 999px.
Type: `--font-ui` "Plus Jakarta Sans", `--font-mono` "JetBrains Mono" (every duration, seed,
BPM and clock is mono). Sizes used: 10.5 · 11 · 11.5 · 12 · 12.5 · 13 · 13.5 · 14 · 14.5 · 15 ·
15.5 · 16 · 17 · 18px. Shadows `--shadow-sm/md/lg` plus the accent CTA glow
`0 8px 22px color-mix(in oklch, var(--accent) 28%, transparent)`.
Motion `--t-fast` 120ms, `--t-med` 220ms, `--ease-out` `cubic-bezier(0.22, 1, 0.36, 1)`.

## Assets
- **Icons** — all from `apps/web/src/components/Icons.jsx` (`Play`, `Pause`, `Star`, `Download`,
  `Trash`, `Refresh`, `Sparkle`, `ChevDown`, `ArrowLeft/Right`, `Close`, `Editor`, `Audio`,
  `Search`, `Menu`, `Warning`). No new icons were drawn; the prototype inlines these exact paths.
- **Logo** — `apps/web/src/components/Logo.jsx` (the scene-cut mark), theme-driven via
  `--logo-ground` / `--logo-seam` / `--teal`.
- **Waveforms** — the prototype's SVG bar paths are synthetic stand-ins generated for the mock
  (`waveforms.json`). In production, derive peaks from the rendered audio (the worker already
  reports `file.duration`, `sampleRate`, `channels`); a downsampled peak array per asset,
  cached beside the clip, is enough to draw the same bar chart. Bars are drawn as one `<path>`
  of vertical strokes with round caps, not per-bar elements.
- **No raster images** are needed. Image/clip cells in the Assets mock use the repo's own
  `.su-asset-placeholder` hatch.

## Files
In this bundle:
- `Audio Studio.dc.html` — the design document. Sections top to bottom: turn 4 (`4a` Simple
  Assets + viewer), turn 3 (`3a` Simple UI, three bands), turn 2 (`2a` the recommended
  Advanced screen), turn 1 (`1a` today's screen recreated from source, plus the three
  explored directions `1b` / `1c` / `1d`). Open it in a browser; the play buttons work.
- `screenshots/1a-current-audio-studio.png` — today's screen, for before/after.
- `screenshots/2a-take-grid-with-play-deck.png` — **the primary target** (Advanced).
- `screenshots/3a-simple-ui-all-bands.png` — Simple UI desktop / tablet / phone.
- `screenshots/4a-simple-assets-and-viewer.png` — Assets grid + viewer, desktop and phone.
- `waveforms.json` — the generated waveform paths used by the mock.
- `github.md` — the source-repo association and screen → source-file map.

Source files to modify in `SceneWorks/SceneWorks` (branch `main`):
- `apps/web/src/screens/AudioStudio.jsx` — work-panel settings grid + the whole results zone
- `apps/web/src/components/WorkerProgressCard.jsx` — reuse `AudioTransport`; the audio lane no
  longer needs the full card in the studio surface
- `apps/web/src/styles.css` — new `.audio-take-*` / deck classes beside `.review-card`
- `apps/web/src/simple/SimpleAudioStudio.jsx` — tabs, notice removal, results
- `apps/web/src/simple/SimpleAssets.jsx` — audio grid tile
- `apps/web/src/simple/SimplePreview.jsx` — audio viewer stage
- `apps/web/src/simple/simple.css` — the few `.su-*` additions for the deck
Reference (read, don't change): `apps/web/src/screens/VideoStudio.jsx` (latest-assets grid),
`apps/web/src/components/assetPanels.jsx` (`AssetCard`), `apps/web/src/simple/breakpoint.js`.
