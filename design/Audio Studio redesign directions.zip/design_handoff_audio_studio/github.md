repo: SceneWorks/SceneWorks
branch: main
path: apps/web/src

## Last sync
date: 2026-07-24T19:48:00Z

### Updated in this project
- Added 2a: run-grouped take grid with a docked play deck (interactive).
- Added 3a: the same idea on the Simple UI shell at all three measured bands (desktop / tablet / phone).
- Simple UI audio modes now use the `.su-tabs` underline tabs the Image and Video studios use, not the segmented control.
- Added 4a: Simple Assets renders audio as a waveform card in the square grid and opens the shared su-preview viewer with a full-size play deck.

### Updated in this project
- Recreated the current Audio Studio screen (work panel + "Latest audio" worker-card stack) from source.
- Added three redesign directions for Latest audio: run-grouped take tiles, console now-playing deck, results-first contact sheet.
- Grounded the shell in source: scene-cut Logo, ProjectSwitcher pill, SimpleModeSwitch footer, full System nav list.

## Screen map (Simple UI)
| Project screen | Repo files |
| --- | --- |
| Audio Studio.dc.html · 3a Simple UI | apps/web/src/simple/SimpleShell.jsx, apps/web/src/simple/SimpleAudioStudio.jsx, apps/web/src/simple/breakpoint.js, apps/web/src/simple/useContainerWidth.js, apps/web/src/simple/simple.css, apps/web/src/components/Logo.jsx |
| Audio Studio.dc.html · 4a Simple Assets + viewer | apps/web/src/simple/SimpleAssets.jsx, apps/web/src/simple/SimplePreview.jsx, apps/web/src/simple/breakpoint.js, apps/web/src/simple/simple.css, apps/web/src/screens/LibraryScreen.jsx |

## Sync history
- 2026-07-24T18:47:22Z — first import: AudioStudio.jsx, VideoStudio.jsx, WorkerProgressCard.jsx, assetPanels.jsx, App.jsx, styles.css.

## Screen map
| Project screen | Repo files |
| --- | --- |
| Audio Studio.dc.html · 1a Current (recreated) | apps/web/src/screens/AudioStudio.jsx, apps/web/src/components/WorkerProgressCard.jsx, apps/web/src/components/WorkPanel.jsx, apps/web/src/components/Icons.jsx, apps/web/src/components/Logo.jsx, apps/web/src/simple/SimpleModeSwitch.jsx, apps/web/src/simple/simple.css, apps/web/src/App.jsx, apps/web/src/styles.css |
| Audio Studio.dc.html · 1b Run-grouped take tiles | apps/web/src/screens/AudioStudio.jsx, apps/web/src/screens/VideoStudio.jsx (latest-assets review grid), apps/web/src/components/assetPanels.jsx (AssetCard), apps/web/src/styles.css |
| Audio Studio.dc.html · 1c Console deck | apps/web/src/screens/AudioStudio.jsx, apps/web/src/components/WorkerProgressCard.jsx (AudioTransport), apps/web/src/styles.css |
| Audio Studio.dc.html · 1d Results-first | apps/web/src/screens/AudioStudio.jsx, apps/web/src/screens/generationStudio.jsx (ModeTabs), apps/web/src/styles.css |
