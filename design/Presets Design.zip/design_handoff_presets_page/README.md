# Handoff: Presets page (focused redesign)

## Overview
A focused redesign of the SceneWorks **Presets** screen — the library where a user saves,
browses, edits, and reuses recurring generation setups ("recipes": a model + prompt scaffold
+ defaults + LoRAs). Today this screen is the app's biggest visual outlier: a dense
card-in-card guided form with big numbered step circles, a giant per-model radio list, and a
sticky right-hand summary sidebar. The redesign brings it in line with the project's
**Page-Frame Standard**: the global topbar owns the title + blurb, and the screen body is a
single **Purpose zone** (one accent-barred work-panel) over a **Results zone** on the bare
canvas.

This maps to the existing screen rendered by **`PresetManagerScreen`** (`activeView === "Presets"`
in `App.jsx`), backed by `hooks/usePresets.js` (`presets`, `createPreset`, `updatePreset`,
`duplicatePreset`, `deletePreset`) and `presetUtils.js`. The redesign reorganizes existing
content — **no new backend features**.

## About the Design Files
The files in this bundle are **design references created in HTML** — a prototype of the
intended look and layout, not production code to copy directly. The task is to **recreate this
design inside the existing SceneWorks web app** (`apps/web`, React + the tokens in
`apps/web/src/styles.css`), reusing its established components (`WorkPanel`, `CompactSelector`,
`Icon`, segmented controls, the LoRA-stack widget, etc.) and class-based CSS. Do **not** ship the
HTML/inline-styles directly.

`SceneWorks Presets.dc.html` is a "Design Component" — it renders standalone in a browser. Its
markup uses inline styles and CSS custom properties that **mirror `styles.css`** (prefixed
`--sw-*` here vs the app's real names). The mapping is 1:1; see **Design Tokens** below.

## Fidelity
**High-fidelity.** Colors, type, spacing, radii, and states are all taken from `styles.css`.
Recreate using the app's real tokens/classes. Preset content (names, prompts, models, counts) is
placeholder sample data.

## What changed (design intent)
1. **Page-Frame Standard applied.** Topbar owns `Presets` + blurb; no per-page hero repeating the
   title. Body = one work-panel (Purpose) + a bare-canvas grid (Results). No card-in-card.
2. **Model list → a plain dropdown.** The old full-width per-model radio cards (every model's
   tags, size, memory, description) are gone. Base model is now a single `<select>` with a short
   mono helper line (`txt2img · img2img · 6.4 GB`). *(Explicit user request.)*
3. **Summary sidebar folded into the flow.** The sticky right-hand `.preset-summary` column is
   removed. Its two jobs are folded inline: the **prompt preview** now lives directly under the
   prefix/suffix fields in the Prompt section, and a compact **Recipe** chip row
   (`model · aspect · variations · LoRAs`) sits in the work-panel's action footer.
4. **Workflow is model-driven.** Workflow moved out of Identity into its own section after Base
   model, and its options react to the selected model (image models → Text/Edit/Character; video
   models → Text → Video / Image → Video / First–Last Frame) so the control never overflows.
5. **Quiet section rhythm, no step numbers.** Sections are a title + one-line description + controls,
   separated by 1px hairlines — the numbered `.preset-section .step` accent pills are dropped.
6. **Advanced disclosure** matches the frame standard: a bordered, header-labelled block whose
   controls open contiguously beneath its own header (not a floating button spawning a detached
   container).

## Screens / Views
One screen, two states, switched by the prototype's `view` tweak.

### A) Manager (`view: list`) — the default landing state
**Purpose:** browse, filter, and create presets; jump one into the Studio.

**Layout (top → bottom):**
1. **Topbar** (global chrome — already in `App.jsx`; do not rebuild). Left: `Presets` + blurb
   `Save and share recurring generation setups.` Right: workspace status pill, divider, avatar dot.
2. **Purpose work-panel** — `--surface`, `--r-lg` (16px), `shadow-md`, and a 3px `--accent` rule across the **top**
   edge (the frame-standard work-panel — the one elevated card on the page),
   `padding: 20px 24px 18px`. Contains, split by a 1px hairline:
   - **Intent + CTA row**: eyebrow `Your presets`, `h2` `Reusable generation setups` (20px/600), a
     description line with a link to Image Studio; and the **New preset** accent-filled CTA
     (top-right) — the primary create entry point.
   - **Toolbar row**: search field (flex, 38px) + scope segmented (`All / This project / Global`)
     + a `type` select (`All types`).
3. **Results zone** — header (eyebrow `Results` + `h2` `Saved presets` + count `6 presets · 2 global`
   + a `Recently used` sort select), then a **2-column grid** (`repeat(2,1fr); gap:14px`) of
   **preset cards**.

**Preset card** (`--surface`, 1px `--border`, `--r-lg`, `padding: 16px`):
- Header: name (15px/600, ellipsis) + workflow · mono model line; a **scope chip** top-right
  (Global = `--accent-soft`/`--accent-strong`; Project = neutral `--surface-2` + faint text).
- **Prompt preview** box (`--bg`, mono 11.5px): faint prefix, accent-soft `{token}` pill, faint suffix.
- **Meta chips** row: aspect, variations, quality (neutral pills), plus a LoRA chip (accent when > 0,
  neutral `No LoRAs` when 0).
- **Action row** (hairline top): `Use in Studio` (accent, play glyph) + `Edit` (secondary) + spacer +
  icon buttons `Duplicate` and `Delete`.

### B) Create / Edit (`view: edit`; `mode: new | saved`)
**Purpose:** author one preset. One work-panel; sections stacked and hairline-separated.

- **Editor header** (inside the panel): a `‹ All presets` back button + `EDIT PRESET` / `NEW PRESET`
  eyebrow on the left; on the right a **status pill** (`Unsaved changes` warn pill when dirty / `Draft`
  neutral for new — the real app shows `Version {n}` when clean) plus **Cancel** (secondary) and the
  primary **Save preset** / **Create preset** button (save glyph, accent glow).
Sections are plain stacked blocks separated by 1px hairlines — a section title + one-line
description, then its controls. (No numbered step circles — dropped as noise.)

- **Identity** — name field on the left (*saved:* borderless 22px input + 28px pencil button;
  *new:* boxed 18px input, placeholder `Name this preset…`) with the **Scope** segmented control
  (`This project / Global`) pulled up to its right to fill the row and save vertical space.
- **Base model** — a single **Model dropdown** + a mono helper line (type flags · size).
  (Replaces the old `.preset-model-cards` per-model radio list.)
- **Workflow** — its own section **after** Base model, and its options are **reactive to the
  selected model**: an image model offers `Text / Edit / Character`
  (`text_to_image / edit_image / character_image`), a video model offers
  `Text → Video / Image → Video / First–Last Frame`. Only the modes the model supports render,
  so the segmented control never overflows. In the app, derive the option set from the model's
  declared capabilities/`ui` (as Image/Video Studio already do) rather than a fixed list.
- **Prompt template** — **Prefix** + **Suffix** textareas (mono) side by side, then the folded-in
  **Live preview** box (prefix in `--text`, `{your prompt}` accent-soft pill, suffix `--text-muted`).
  Maps to `.prompt-template` / `.prompt-preview`.
- **Defaults** — Aspect (select), Variations (number), Quality (segmented `Fast / Balanced / Quality`).
  Maps to `.preset-defaults-grid` / `.quality-pick`. For a video-workflow preset, swap in
  Duration + Frames as the existing screen does.
- **LoRAs** *(optional)* — the existing LoRA stack: per-LoRA slot (name + kind·size, mono weight
  readout, remove ✕, 0–1 weight range) + a dashed **Add LoRA** button with a mono `N available` count.
  Maps to `.lora-stack` / `.lora-slot` / `.lora-add`.
- **Advanced** — bordered disclosure; header row (`Advanced` + hint + `Hide/Show` + caret) toggles a
  contiguous body: Steps, Guidance, Sampler, Scheduler, Seed.
- **Action footer** (hairline top): the **Recipe** chip summary (folded from the old sidebar) on the
  left; Cancel + Save preset on the right (mirrors the header actions).

All controls lock to the standard control height (inputs/selects/segments on a shared baseline;
textareas grow from a 2-row min). Transitions use `--t-fast` (120ms) / `--t-med` (220ms) with
`--ease-out` `cubic-bezier(0.22,1,0.36,1)`.

## Interactions & Behavior
- **Create:** `New preset` (manager) → editor in `new` state (boxed empty name, `Draft`, `Create preset`).
- **Edit / Duplicate / Delete / Use in Studio:** card actions → `updatePreset` / `duplicatePreset` /
  `deletePreset` / launch Image Studio with the recipe (`sendAssetRecipeToImage`-style launch).
- **Scope & type filters + search + sort:** client-side filtering/sorting of the card grid.
- **Rename:** the pencil button focuses the name input (saved state).
- **Prompt preview** recomputes live from the prefix/suffix fields.
- **Save/Create:** disabled until `canSave`; label follows `new` vs existing.

## State Management
Owned by `PresetManagerScreen` (already implemented) + `usePresets.js`. Relevant pieces: `presets`,
`selectedPresetId`/`activePreset`, `creating`/`editing`, `draftName`, `scope`, `workflow`/`mode`,
`model`, `promptPrefix`/`promptSuffix`, `defaults` (aspect/variations/quality), `loras` (id + weight),
`advanced` (steps/guidance/sampler/scheduler/seed), `dirty`/`canSave`. No new state is introduced.

## Design Tokens
Prototype var → real `styles.css` var (use the real ones):

| Prototype | styles.css | Value (dark) |
|---|---|---|
| `--sw-bg` / `--sw-bg2` | `--bg` / `--bg-2` | `oklch(0.165 .012 240)` / `oklch(0.145 .012 240)` |
| `--sw-surface` / `--sw-surface2` | `--surface` / `--surface-2` | `oklch(0.205 .012 240)` / `oklch(0.235 .014 240)` |
| `--sw-hover` | `--surface-hover` | `oklch(0.255 .014 240)` |
| `--sw-border` / `--sw-border2` | `--border` / `--border-strong` | `oklch(0.285 .014 240)` / `oklch(0.36 .016 240)` |
| `--sw-text` / `--sw-muted` / `--sw-faint` | `--text` / `--text-muted` / `--text-faint` | `0.96` / `0.72` / `0.56` L, `.012 240` |
| `--sw-accent` / `-strong` / `-soft` / `-fg` | `--accent` / `--accent-strong` / `--accent-soft` / `--accent-fg` | hue-driven `--accent-h` (teal 178 default) |
| `--sw-warn` / `--sw-warn-soft` | `--warn` / `--warn-soft` | `oklch(0.82 .14 80)` / `oklch(0.33 .07 70)` |
| `--sw-ok` | `--success` | `oklch(0.62 .13 155)` |

- **Accent** is hue-driven (`--accent-h`); the prototype's `accent` tweak mirrors the app's seven
  palettes (teal 178 default, indigo 274, cobalt 252, violet 305, coral 28, amber 80, emerald 152).
  One `[data-accent]` swap recolors the whole screen.
- **Type:** `--font-ui` Plus Jakarta Sans (400/500/600/700); `--font-mono` JetBrains Mono.
- **Radius:** xs 6 / sm 8 / md 12 / lg 16 / xl 22 / pill 999.
- **Spacing:** gaps 6/10/14/20/28; `--pad-panel` 20.
- **Light theme** exists in `styles.css`; the prototype shows dark only. Recreation must honor both
  via tokens.

## Assets
- **Icons:** use the existing `apps/web/src/components/Icons.jsx` set (Plus, Search, pencil, play,
  duplicate, trash, save, chevrons). The prototype's inline SVGs are stand-ins.
- No new image assets are required.

## Files
- `SceneWorks Presets.dc.html` — the hi-fi design prototype (this bundle). Tweaks: `view` (`list`/`edit`),
  `mode` (`saved`/`new`), `model` (drives the reactive Workflow options), `accent`.
- `support.js` — runtime for the prototype (lets the HTML open standalone; not for production).
- In the app, the screen to update:
  - `apps/web/src/screens/PresetManagerScreen.jsx`
  - supporting: `hooks/usePresets.js`, `presetUtils.js`, `components/WorkPanel.jsx`,
    `components/CompactSelector.jsx`, `components/Icons.jsx`, tokens in `styles.css`.
