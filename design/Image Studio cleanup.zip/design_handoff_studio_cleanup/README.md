# Handoff: Image & Video Studio settings-panel cleanup

## Overview

A cleanup pass on the SceneWorks **Image Studio** and **Video Studio** generation screens. Five changes, all inside the studio work-panel:

1. **Structure control** now uses the app's one canonical `AdvancedSection` disclosure instead of its own bespoke `.advanced-toggle` header, and it sits directly **above** the Advanced disclosure (previously it was a `.studio-source-band` above the settings bar).
2. **LoRAs** no longer reads as a separate card inside the settings bar — it is a hairline-separated section of the settings container, with the same eyebrow label and type scale as Model / Style.
3. **Style** and **Style preset** are laid out on one two-column grid so their labels and controls align (previously a flex row with `align-items: flex-start`, which left them visibly offset).
4. **Save as preset** moved out of Advanced and inline into the Style-preset chip row: a fixed 140px name input plus a **Save as preset** dropdown whose menu carries the scope (This project / All projects), replacing the wide segmented scope control.
5. **Add LoRA** always opens its picker (it used to be disabled with no available LoRAs), and the picker embeds the Model Manager's **Import LoRA** panel after the available-LoRA list, so a user can import and use a LoRA without leaving the studio.

Video Studio received the same 2–5 (it has no Structure control upstream), and its abstract **Quality** segment was replaced by the concrete **Quant tier** select used in Image Studio.

## About the Design Files

The files in this bundle are **design references authored in HTML** — streaming prototypes that show the intended layout, styling, and behavior. They are **not production code to copy**. The task is to apply these changes to the real SceneWorks web app (`apps/web/`, React + Vite), editing the existing components listed under **Files → Upstream sources** and reusing the existing classes in `apps/web/src/styles.css`. Nearly every value below already exists as a class or CSS variable upstream; prefer reusing it over adding new CSS.

## Fidelity

**High-fidelity.** Colors, type, spacing, and radii are the real SceneWorks OKLCH tokens (`var(--accent)`, `var(--surface-2)`, `var(--r-md)`, `var(--gap-2)`, …) read from `apps/web/src/styles.css`. The prototypes inline those tokens rather than using the classes, purely so they render standalone; in the app, use the classes.

Content (model names, LoRA names, presets, motion chips, asset tiles) is representative sample data.

## Screens / Views

### 1. Image Studio (`Image Studio.dc.html`)

**Purpose:** compose a prompt, pick model + settings, generate stills.

**Layout** — unchanged shell: `.app` grid `var(--side-w) minmax(0,1fr)`, `height:100vh; overflow:hidden`; scrolling `.sidebar` (`var(--bg-2)`, right hairline) and `.workspace` with a sticky `.topbar`. Inside, `.page-frame` (flex column, 18px gap, 22px horizontal margins) → `.studio-shell` (grid, `var(--gap-4)`) → one `.work-panel` (`--surface`, 1px `--border`, `--r-lg`, `--shadow-md`, 3px accent `.work-panel-rule`) and a `.studio-results` `.review-panel` below.

Work-panel children, in order:

1. `.prompt-hero-top` — `.mode-tabs` (Text / Edit / With character), `.batch-toggle`, `.prompt-hero-links` (Prompt guide, Saved presets)
2. `.prompt-input-row` — `.prompt-input` textarea + `.prompt-cta` Generate
3. `.prompt-tools` — three `.prompt-tool` tiles
4. **`.settings-bar`** (changed — see below)
5. **Structure control** — `AdvancedSection` (changed, moved)
6. **Advanced** — `AdvancedSection` (Save-as-preset removed)
7. `ValidationSummary`

#### `.settings-bar` (the "model panel") — the heart of this handoff

`display:grid; gap:12px; padding:12px 14px; border:1px solid var(--border); border-radius:var(--r-md); background:var(--surface-2)`. Four stacked sections, each after the first separated by `border-top:1px solid var(--border); padding-top:12px`:

**a. Model row** — existing `.settings-bar-row` (`display:flex; flex-wrap:wrap; gap:14px; align-items:flex-end`) with four `.settings-field`s:

| Field | flex | Control |
| --- | --- | --- |
| Model | `2 1 200px`, min 160px | select |
| Aspect | `1 1 130px`, min 120px | select |
| Variations | `0 1 96px`, min 82px | number input |
| Quant tier | `1 1 130px`, min 120px | select — `Q8 · balanced` / `bf16 · best` / `Q4 · fastest` |

`.settings-field` label: 10.5px / 700 / `0.06em` / uppercase / `--text-faint`, 5px gap. Controls: `height:36px`, `--surface`, 1px `--border`, `--r-sm`, `padding:8px 10px`, `400 13px var(--font-ui)`, `letter-spacing:normal; text-transform:none`.

> Quant tier lives in this row (it was a separate control before). Keep it here.

**b. LoRAs** (change 2) — was `.settings-bar > .lora-picker`, a bordered `--surface` card with a 400-weight `<strong>LoRAs</strong>` heading and 14px slot titles. Now:

- Section: `border-top` separator, `display:grid; gap:8px`.
- Header row: `display:flex; align-items:baseline; justify-content:space-between`. Left = `.settings-bar-label` **LORAS** (10.5px/700/0.06em/uppercase/`--text-faint`) — the same eyebrow as Model and Style. Right = 11px `--text-muted` status: `"{n} selected · installed and compatible"`, or `"Installed and compatible"` / `"Choose a model"` per the existing `LoraPickerSection` copy.
- Each selected LoRA (was `.lora-slot`): 1px `--border`, `--r-sm` (was `--r-md`), `--surface`, `padding:9px 11px` (was `12px 14px`), `display:grid; gap:8px`.
  - Head: name `13px/600` (was 14px) with ellipsis; meta `11px --text-muted` (`"{scope} · {family}"`); remove button 24×24 (was 28), `--text-muted`, hover `--surface-hover` + `--danger`.
  - Weight: label row `11.5px --text-muted` with a `var(--font-mono) 11.5px` value; `<input type=range>` `accent-color:var(--accent); height:4px`.
- **Add LoRA** button (was `.lora-add`, 14px padding block, 13px text, `1.5px dashed --border-strong`): now `height:34px`, `1px dashed var(--border-strong)`, `--r-sm`, 12.5px/500 `--text-muted`, centered `Icon.Plus size 14` + "Add LoRA" + a `var(--font-mono) 11px` `· {n} available` counter at 0.7 opacity. Hover: `border-color:var(--accent); color:var(--accent-strong); background:var(--accent-soft)`.
  - **Always enabled** (change 5). Upstream it is `disabled={!availableLoras.length}` and the panel is gated on `pickerOpen && availableLoras.length`; both gates come out.
- **Picker panel** (was `.lora-picker-panel`): 1px `--border`, `--r-sm`, `--bg-2`, `padding:8px`, `display:grid; gap:8px`. Contents in order:
  1. Available-LoRA rows (`.lora-pick-row`): `padding:7px 10px`, 1px `--border`, `--r-sm`, `--surface`, name 12.5px/600 + 11px muted meta, right-side "Add" in `--accent-strong` (or "Limit reached" when at `MAX_USER_JOB_LORAS`). Hover `border-color:var(--accent)`.
  2. When none: one 12px `--text-muted` line — reuse `loraEmptyMessage`, e.g. *"No other installed LoRAs match Z-Image-Turbo — import one below."*
  3. **Import LoRA** panel — the Model Manager form, recreated verbatim from `ModelManagerScreen.jsx` (see below).

**c. Import LoRA panel** (change 5, nested in the picker) — reuses `.models-accent-band .models-import-panel`:

- Band: `display:flex; flex-direction:column; gap:11px` (upstream 13px), `padding:13px` (upstream 16px), `border-radius:var(--r-md)`, `background:color-mix(in oklch, var(--accent) 5%, var(--surface))`, `border:1px solid color-mix(in oklch, var(--accent) 22%, var(--border))`.
- `.models-accent-band-head`: `.models-accent-dot` (7×7, `--accent`, `0 0 0 3px color-mix(in oklch, var(--accent) 22%, transparent)`), `.eyebrow` **IMPORT LORA** in `--accent-strong`, and `.models-accent-band-caption` (12px `--text-muted`, `margin-left:auto`) "Add a LoRA from a URL or file — auto-detects family".
- `.compact-segment` URL / Upload, `align-self:flex-start`, `--bg-2`, 1px `--border`, `--r-sm`, `padding:2px`; buttons `min-height:30px; padding:6px 10px`, active = `--surface` + `--shadow-sm`.
- `.models-import-grid`: `grid-template-columns: minmax(110px,0.6fr) minmax(130px,0.8fr) minmax(220px,1.7fr) minmax(140px,1fr) auto; gap:8px; align-items:end`. Cells: Scope (Global / Project), Family (Auto-detect + families), then **Source URL** input *or* — in Upload mode — a `.file-picker-row` (`grid-template-columns:max-content minmax(0,1fr)`) with a `.file-upload-button` "Choose" and `.selected-file-name` (13px `--text-muted`, ellipsis, "No file selected"), then Name (placeholder "Optional"), then the submit button "Queue import". Labels `display:grid; gap:7px` per `.models-import-panel label`.
- `.lora-import-metadata` (`display:grid; gap:8px`): **Trigger keywords** via the existing `KeywordTagEditor` — `.kw-editor-field` (`flex-wrap`, `gap:6px`, `padding:6px 8px`, 1px `--border`, 8px radius, `--surface-2`, `min-height:34px`, `cursor:text`), `.kw-chip` (`--accent-soft` / `--accent-strong`, `--r-pill`, `padding:2px 4px 2px 9px`, 11.5px/500, 16px round × button), `.kw-input` (borderless, transparent, 12.5px); and **Notes** textarea, 2 rows.
- Closing `.helper-copy` (12px `--text-muted`): "Imported LoRAs land in your library and become selectable here — no trip to Model Manager."
- Wire the submit to the existing `createLoraImportJob`; on success the new LoRA should appear in the picker list (and may be auto-selected).

> **Implementation note:** in the prototype this is a `<div role="group">`, not a `<form>`, because the studio screen is already one `<form>` and nested forms are invalid. In the app, either lift the import into a sibling form or keep it a div and submit via a click handler.

**d. Style axis** (changes 3 + 4) — was `.settings-bar-styles.settings-bar-style-axis`, `display:flex; flex-wrap:wrap; gap:16px 20px; align-items:flex-start` with `.style-axis-catalog` (`flex:0 0 auto`) and `.style-axis-presets` (`flex:1 1 240px`). Now a grid so the two columns' labels and controls line up:

```css
display: grid;
grid-template-columns: minmax(240px, auto) minmax(0, 1fr);
gap: 16px 20px;
align-items: start;
```

- **Style** column: `.settings-bar-label` STYLE, then the `StylePicker` `.compact-selector-pill` in a `min-height:44px` flex-centered wrapper; pill `height:44px`, thumb 26×26.
- **Style preset** column: `.settings-bar-label` STYLE PRESET, then one wrapping row (`min-height:44px; display:flex; flex-wrap:wrap; align-items:center; gap:6px`) holding, in order:
  1. `.preset-chip` buttons (None + each available preset) — `padding:5px 11px`, `--r-pill`, 12px/500, `--surface-2` + 1px `--border` + `--text-muted`; active = `--accent-soft` / `--accent-strong` / `border-color:transparent` / 600.
  2. A 1px × 22px `--border` divider with `margin:0 4px`.
  3. Preset **name input** — fixed `width:140px; flex:0 0 auto; height:30px; padding:0 11px; border-radius:var(--r-pill); border:1px solid var(--border); background:var(--surface); font-size:12px`, placeholder "Name this setup…".
  4. **Save as preset** dropdown — `height:30px; padding:0 10px 0 12px; --r-pill`, 1px `--border`, `--surface-2`, 12px/600 `--text-muted`, `Icon.Preset size 13` + label + a 13px chevron at 0.6 opacity. Hover: `--accent-soft`, `border-color:transparent`, `--accent-strong`. Menu = `.compact-selector-menu` (absolute, `top:calc(100% + 6px)`, `z-index:30`, `padding:6px`, `--surface`, 1px `--border`, `--r-md`, `--shadow-lg`) with two `.compact-selector-item` options: **This project** / *Only {project name}* and **All projects** / *Available everywhere* (title 12.5px/600, hint 11px muted). Selected row = `--accent-soft` / `--accent-strong`. Disable "This project" with no active project, mirroring the current `SavePresetPanel`.
  5. Validation + save message keep their existing `ValidationSummary` / `.inline-success` / `.inline-warning` treatment (place them under the row).
- **Style description** (`PresetGuidanceStrip`) — was a standalone `.guidance-strip` card between the settings bar and Advanced. Now the last row of this grid: `grid-column:1 / -1; display:grid; gap:3px; padding-top:10px; border-top:1px solid var(--border); font-size:12.5px` — title 600, "Adds: …" line in `--text-muted`. No card, no border box.

#### Structure control (change 1)

Delete the bespoke `.control-panel` header (`.advanced-toggle.control-panel-toggle` + `.control-panel-chev` + `.control-panel-desc` indent) and render `ControlPanel`'s body inside the shared `AdvancedSection`:

- `label="Structure control"`, `hint="lock pose, edges, or depth to a reference"`, default collapsed (the prototype shows it open).
- Chrome comes from `AdvancedSection`: `.advanced-section` (1px `--border`, `--r-md`, `--surface-2`, `overflow:hidden`), `.advanced-section-head` (`padding:11px 14px`, `gap:var(--gap-2)`), `.eyebrow.advanced-section-label` in `--accent-strong`, `.advanced-section-hint` 11.5px `--text-faint`, and the right-hand caret button ("Show"/"Hide" 11px `--text-faint` + `Icon.ChevDown`, rotating 180° when open). Body: `.advanced-section-body`, `padding:14px`, `gap:var(--gap-2)`, top hairline when open.
- Body content is unchanged `ControlPanel`: helper line (12px `--text-faint`, no 20px indent now), `.control-mode-tabs` (Pose / Canny / Depth), the pose picker or control-image picker, and the `.reference-strength` control-strength slider with a mono value.
- **Position:** immediately above the Advanced `AdvancedSection`, i.e. after the settings bar — not in a `.studio-source-band` above it.

#### Advanced

Unchanged except that `SavePresetPanel` is removed (it now lives in the style-preset row). Fields stay: GPU, Seed, Width override, Height override, Sampler, Scheduler, Negative prompt — `.advanced-panel` at `repeat(2, minmax(0,1fr))`.

### 2. Video Studio (`Video Studio.dc.html`)

Same shell and the same settings-bar treatment. Differences, all matching `VideoStudio.jsx`:

- Mode tabs: Text → Video / Image → Video / First → Last / Extend / Bridge / Replace person, on `.mode-tabs.mode-control` (`max-width:min(720px,100%)`). No Batch toggle.
- CTA label "Render clip" ("Replace person" in that mode).
- `RefinePromptControl` sits between `.prompt-input-row` and the motion row: `.refine-control` grid with a `.hero-link.refine-button` ("Refine my prompt", `Icon.Wand size 14`, `justify-self:start`, 1px `--border`, `--surface`) and, after a run, the `.refine-review` card (`padding:12px 14px`, 1px `--border`, `--r-md`, `--surface-2`) with `.refine-review-label` "SUGGESTED REWRITE" (11.5px/600/uppercase/0.04em/muted), `.refine-review-text` (14px/1.5, `pre-wrap`) and `.refine-review-actions` Apply / Keep original as `.secondary-action`s.
- `.motion-row`: "Motion:" label (12.5px muted) + `.motion-chip` pills (static, slow push-in, pull out, pan left, pan right, tilt up, tilt down, handheld) — `padding:5px 11px`, `--r-pill`, `--surface` + 1px `--border` + muted; active `--accent-soft` / `--accent-strong` / 600; the `→` `.motion-arrow` is 0.55 opacity, 1 when active.
- Model row: Model, **Resolution**, **Duration**, **Quant tier**. The old `.quality-segment` (Fast / Balanced / Best) is **removed** — "Quality" was too abstract for this screen; use the same Quant tier select as Image Studio.
- No Structure control (Video Studio has no `ControlPanel` upstream).
- Advanced: Frames, GPU, Seed, Steps, Guidance, Character, Look, Negative prompt.
- Results tiles are 16:9.

## Interactions & Behavior

- **Disclosures** — header row and caret both toggle; collapsed renders header only (no reserved space). Caret rotates 180° over `var(--t-fast)` `var(--ease-out)`; label flips Show ⇄ Hide.
- **Add LoRA** — click toggles the picker; always available. Picking a row adds the LoRA and closes the list. Import panel stays open for a second import.
- **Import mode** — URL ⇄ Upload swaps the third grid cell between a URL input and the file picker; the chosen filename replaces "No file selected".
- **Trigger keywords** — Enter or comma commits a chip; Backspace on an empty input removes the last; `×` removes a chip.
- **Save as preset** — the dropdown opens the scope menu; picking a scope sets it (and, per current behavior, is where "save" fires — keep the existing `handleSaveAsPreset` on the primary action and treat the menu as scope selection + confirm). Empty name stays silent; errors surface in `ValidationSummary`.
- **Preset chips / motion chips / mode tabs / control tabs** — single-select, immediate.
- Hover states throughout are the standard quiet surface shift (`--surface-hover`, or `--accent-soft` on accent-tinted controls). No scale transforms.

## State Management

No new app state beyond what already exists (`useGenerationStudio`, `useSavePreset`, `ControlPanel`'s local `open`). What changes:

- `ControlPanel`'s local `open` becomes the `AdvancedSection` `open`/`onToggle` pair (still local, still collapsed by default).
- The LoRA picker's `pickerOpen` no longer depends on `availableLoras.length`.
- New local state for the in-studio import form, mirroring `ModelManagerScreen`'s `importForm`: `{ mode, scope, family, sourceUrl, file, name, triggerKeywords, notes }` + `importing` + `importMessage`. Submit through the existing `createLoraImportJob`; refresh the LoRA catalog on completion.
- Save-preset scope state is the existing `presetScope`; only its presentation changes (menu instead of segment).

## Design Tokens

All from `apps/web/src/styles.css` / the `@sceneworks/ui` token files — no new values.

- **Color:** `--bg`, `--bg-2`, `--surface`, `--surface-2`, `--surface-hover`, `--border`, `--border-strong`, `--text`, `--text-muted`, `--text-faint`, `--accent`, `--accent-strong`, `--accent-soft`, `--accent-fg`, `--danger`, `--warm`, `--success`; brand `--ink #0f1622`, `--mist #b9babb`, `--paper #fbfaf6`, `--teal #2fa193`. Tints via `color-mix(in oklch, …)`.
- **Spacing:** `--gap-1..5` = 6 / 10 / 14 / 20 / 28; `--pad-panel`; ad-hoc 7 / 8 / 11 / 12 / 13 / 14 / 16 px inside the panels above.
- **Type:** `--font-ui` (Plus Jakarta Sans), `--font-mono` (JetBrains Mono). Sizes used: 10.5 eyebrow/700/0.06em, 11 / 11.5 meta, 12 / 12.5 body-small, 13 controls, 13.5 buttons, 14 body, 16 results heading, 17 topbar title.
- **Radius:** `--r-xs 6`, `--r-sm 8`, `--r-md 12`, `--r-lg 16`, `--r-pill 999`.
- **Elevation:** `--shadow-sm/md/lg`, `--shadow-glow` (focus).
- **Motion:** `--t-fast 120ms`, `--t-med 220ms`, `--ease-out cubic-bezier(0.22, 1, 0.36, 1)`.
- **Density:** `--side-w 232`, `--control-h 38`, `--row-h 40`; buttons 36, primary CTA 44, compact controls 30 / 34.

## Assets

- Brand mark and wordmark: the existing `Logo` / `Wordmark` components (`apps/web/public/sceneworks-logo.svg`) — do not redraw.
- Icons: the app's own `Icon` set (`apps/web/src/components/Icons.jsx`) — 24×24, 1.7px stroke, `currentColor`. Used here: `Image`, `Video`, `Audio`, `Character`, `Guide`, `Train`, `ImageEditor`, `Editor`, `Library`, `Storyboard`, `Sliders`, `Preset`, `Model`, `Queue`, `Chart`, `Logs`, `Book`, `Folder`, `Sparkle`, `Stars`, `Wand`, `Plus`, `ChevDown`, `Bell`, `Moon`. No new glyphs.
- Media thumbnails are the app's diagonal-checkerboard placeholder (`repeating-linear-gradient(45deg, color-mix(in oklch, var(--accent) 20%, transparent) 0 6px, transparent 6px 12px)` over `color-mix(in oklch, var(--warm) 14%, var(--surface))`). No photography in this bundle.

## Files

**In this bundle**

- `Image Studio.dc.html` — Image Studio prototype (streaming Design Component; opens directly in a browser)
- `Video Studio.dc.html` — Video Studio prototype
- `support.js` — runtime the two prototypes need; not part of the app
- `screenshots/01–04-image-studio.png` — full page, settings bar / LoRAs, Add-LoRA picker with the Import LoRA panel, Save-as-preset dropdown open
- `screenshots/01–03-video-studio.png` — full page, settings bar, Add-LoRA picker with the Import LoRA panel
- Design-system tokens/styles are loaded from `_ds/…` in the parent project; the app already has these values in `apps/web/src/styles.css`.

**Upstream sources to edit (SceneWorks/SceneWorks @ main)**

- `apps/web/src/screens/ImageStudio.jsx` — settings-bar composition, section order, Advanced contents
- `apps/web/src/screens/VideoStudio.jsx` — same, plus the Quality → Quant tier swap
- `apps/web/src/components/ControlPanel.jsx` — swap its bespoke header for `AdvancedSection`
- `apps/web/src/components/AdvancedSection.jsx` — the canonical disclosure (reference; likely unchanged)
- `apps/web/src/components/generationStudio.jsx` — `LoraPickerSection`, `StyleAxisRow`, `SavePresetPanel`
- `apps/web/src/screens/ModelManagerScreen.jsx` — the Import LoRA form to lift into the picker
- `apps/web/src/components/KeywordTagEditor.jsx` — trigger-keyword editor
- `apps/web/src/components/StylePicker.jsx`, `apps/web/src/components/RefinePromptControl.jsx` — unchanged, referenced
- `apps/web/src/styles.css` — `.settings-bar*`, `.style-axis-*`, `.lora-*`, `.save-preset*`, `.control-panel*`, `.advanced-section*`, `.models-accent-band*`, `.models-import-grid`, `.kw-*`, `.motion-*`, `.quality-segment` (now unused on these screens)
