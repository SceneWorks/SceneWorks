# Handoff: SceneWorks Page-Frame Standard (direction "1b")

## Overview
SceneWorks pages are inconsistent: every screen invents its own header, several
nest a card inside a card inside a hero (wasting vertical space), and the same
conceptual controls look different from page to page. This handoff defines **one
page-frame standard** and applies it across screens, so every page reads the
same way and reclaims the wasted space — while keeping the existing look and feel
(dark theme, teal accent, Plus Jakarta Sans).

The chosen direction is **"1b" — Work-panel + Results canvas.**

## About the design files
The two files in this bundle are **design references authored in HTML**
(`*.dc.html`) — prototypes that show the intended look and behavior. They are
**not production code to copy**. The task is to **recreate them inside the
existing SceneWorks web app** (`apps/web`, React + Vite) using its established
patterns and its single stylesheet, `apps/web/src/styles.css`. Almost every
token and several components (e.g. `.mode-tabs`) already exist in that file — the
work is mostly **reorganizing existing markup/classes into the standard**, not
inventing new CSS.

To view the references: open either `.dc.html` in a browser (both load the
included `support.js` from the same folder). `SceneWorks Frame Spec.dc.html` is
the authoritative spec; `SceneWorks Frame Standard.dc.html` shows the earlier
option exploration (1a/1b/1c) for context.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and radii are the app's real
tokens (pulled verbatim from `styles.css`). Recreate pixel-for-pixel using the
existing tokens and classes. Placeholder image tiles (diagonal stripes) stand in
for real generated media — use the app's real asset/thumbnail components there.

---

## The standard (apply to EVERY screen)

Three fixed bands, top to bottom:

1. **Topbar** — global chrome (already exists: `.topbar` / `.topbar-title`).
   It is the **only** place the page is named (`<h1>` + one-line blurb). No page
   may repeat its own title below.
2. **Purpose zone** — a single **work-panel** card holding the page's core action
   (its primary input/controls + tabs). Exactly one elevated card per page.
3. **Results zone** — what the page produces (grid / list / stream), flush on the
   plain workspace background. **No wrapping card.**

### Rules
- **Delete the per-page hero.** Remove `.surface-header.hero`, its gradient
  background, and the decorative `::after` orb everywhere.
- **Stop wrapping whole screens in `.main-surface`.** Today `.main-surface` is a
  bordered, padded card that wraps the entire page, producing card-in-card
  nesting. Under the standard, the page is: work-panel card + bare results. The
  results region gets no card.
- **One elevated card per page** (the work-panel). Results tiles/rows may have
  their own thin borders, but there is no outer container card around them.
- Curated/"getting-started" content that belongs to the action (e.g. Model
  Manager's Recommended picks) lives **inside** the work-panel, not floating on
  the canvas.

---

## Design tokens
All already defined in `apps/web/src/styles.css` `:root` / `[data-theme="dark"]`.
Reuse the CSS variables — do not hardcode. Dark-theme resolved values shown for
reference.

### Color (dark)
| Token | Value (oklch unless noted) | Use |
|---|---|---|
| `--bg` | `oklch(0.165 0.012 240)` | workspace background |
| `--bg-2` | `oklch(0.145 0.012 240)` | sidebar, sunken strips |
| `--surface` | `oklch(0.205 0.012 240)` | cards / work-panel |
| `--surface-2` | `oklch(0.235 0.014 240)` | insets, segmented tracks |
| `--surface-hover` | `oklch(0.255 0.014 240)` | hover |
| `--border` | `oklch(0.285 0.014 240)` | hairlines, card borders |
| `--border-strong` | `oklch(0.36 0.016 240)` | emphasized borders |
| `--text` | `oklch(0.96 0.008 240)` | primary text |
| `--text-muted` | `oklch(0.72 0.012 240)` | secondary text |
| `--text-faint` | `oklch(0.56 0.012 240)` | labels, meta |
| `--accent` | `oklch(0.74 0.11 178)` | teal accent (hue-driven) |
| `--accent-strong` | `oklch(0.82 0.12 178)` | accent text on dark |
| `--accent-soft` | `oklch(0.3 0.06 178)` | accent chip fills |
| `--accent-fg` | `oklch(0.16 0.012 240)` | text on accent buttons |
| `--teal` (brand) | `#2fa193` | logo mark only (fixed) |
| `--danger` | `oklch(0.62 0.18 25)` | destructive |
| `--warn` | `oklch(0.66 0.15 70)` | warnings / gated |
| `--success` | `oklch(0.62 0.13 155)` | ready/ok |

Accent is **hue-driven**: `--accent-h` is set per `[data-accent]` palette and the
ramps derive from it, so one attribute swap recolors the app. Keep that
mechanism.

### Type — `--font-ui` Plus Jakarta Sans · `--font-mono` JetBrains Mono
| Role | Size / weight |
|---|---|
| Topbar title (`h1`) | 17 / 600 |
| Section heading (`h2`) | 22 / 600, letter-spacing −0.01em |
| Body / control | 13–14 / 400–500 |
| Eyebrow / label | 10–11 / 700, uppercase, letter-spacing .06–.10em |
| Data / sizes | JetBrains Mono 11–12 |

### Radius (`--r-*`)
`xs 6 · sm 8 · md 12 · lg 16 · xl 22 · pill 999`. Work-panels use **16 (`--r-lg`)**;
controls use **8 (`--r-sm`)**; tiles use **10–12**.

### Spacing (`--gap-*`) & density
`gap 6 / 10 / 14 / 20 / 28` · `--pad-panel 20` · `--row-h 40`. Work-panel padding
= 20; page content gap between purpose and results = 18–20.

### Shadow / motion
`--shadow-md: 0 4px 14px rgba(15,23,42,.07), 0 1px 2px rgba(15,23,42,.04)` on the
work-panel. Ease `cubic-bezier(.22,1,.36,1)`; `--t-fast 120ms`, `--t-med 220ms`.

---

## Components

### 1. Work-panel (Purpose zone container) — NEW
The one elevated card per page.
- `background: var(--surface)`; `border: 1px solid var(--border)`;
  `border-radius: var(--r-lg)` (16); `padding: var(--pad-panel)` (20);
  `box-shadow: var(--shadow-md)`.
- A **3px accent top-rule**: an absolutely-positioned bar across the top,
  `linear-gradient(90deg, var(--accent), color-mix(in oklch, var(--accent) 30%, transparent))`.
- Vertical stack (`display:flex; flex-direction:column; gap:14–16px`).
- Suggested React component: `<WorkPanel>` wrapping the header/tabs/inputs.

### 2. Underline tabs — ALREADY EXISTS (`.mode-tabs` / `.mode-tab`)
This is the canonical tab pattern. Reuse it everywhere (studios AND Model
Manager). Do **not** use segmented/pill buttons for page tabs.
- `.mode-tabs`: `display:flex; border-bottom:1px solid var(--border)`.
- `.mode-tab`: `padding:11px 2px; margin-right:26px; margin-bottom:-1px;
  font:14px/1 500; color:var(--text-muted); border-bottom:2px solid transparent`.
- `.mode-tab.active`: `color:var(--text); font-weight:700;
  border-bottom-color:var(--accent)`.
- Optional trailing count pill; on the active tab it uses
  `--accent-soft` / `--accent-strong`.

### 3. Controls — ONE HEIGHT (the fix for the mismatched inputs/selects)
Root cause: a native `<select>` computes its own height from OS font + chrome, so
it never matches an `<input>` even with identical padding. Fix once, globally:

```css
:root { --control-h: 38px; }

input[type="text"], input[type="search"], input[type="number"],
input[type="password"], select, .field {
  height: var(--control-h);
  box-sizing: border-box;          /* border + padding INSIDE the height */
  padding: 0 12px;                 /* centre via height, not vertical padding */
  font: 500 13px/1 var(--font-ui);
  color: var(--text);
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r-sm);
}
select {
  appearance: none;                /* <-- removes the OS chrome that breaks height */
  -webkit-appearance: none;
  padding-right: 30px;             /* room for our caret */
  background-image: url("…caret.svg");   /* supply a caret; --text-faint */
  background-repeat: no-repeat;
  background-position: right 11px center;
}
textarea {                         /* multiline is the only opt-out */
  height: auto;
  min-height: calc(var(--control-h) * 2);
  padding: 9px 12px;
  line-height: 1.4;
}
select:focus, input:focus { outline: none; border-color: var(--accent); box-shadow: var(--shadow-glow); }
```
Buttons that sit inline with fields (e.g. "Generate", "Add job") should also be
`height: var(--control-h)` so a whole control row shares one baseline.

> **Not yet exhaustive.** This standard defines the height rule and the common
> control shapes, but it has **not** enumerated every control variant in the app
> (sliders, steppers, keyword/tag editors, curve editor, color grade, file-upload
> button, the compact selectors, etc.). Migrate **page by page**: as you touch a
> screen, bring every visible control onto `--control-h` + `box-sizing:border-box`
> (+ `appearance:none` for selects). Treat the list above as the baseline, not the
> full inventory.

### 4. Advanced section — pattern
For screens with a lot of optional controls (Image/Video Studio). Advanced
expands **in place, below the work-panel** — never inside it, so the Purpose zone
stays a fixed height.
- Bordered section: `border:1px solid var(--border); border-radius:12px;
  background:var(--surface)`.
- Header row (`--surface-2` fill, bottom border): eyebrow "Advanced" in
  `--accent-strong` + a hint + a collapse caret + "Reset to model defaults".
- Body: a grouped grid (`repeat(4,1fr)`) of override fields, then LoRAs row, then
  a toggles row (switch pills). All fields obey the control-height rule.

### 5. Toolbar & filters
- Exactly **one filled primary** button (`background:var(--accent);
  color:var(--accent-fg)`); everything else is `--surface`/`--bg` with a border.
- Segmented control (pill track on `--surface-2`) **only** for a true either/or
  toggle (e.g. Assets vs Trashcan, source/level filters) — never for page tabs.
- Checklines: 15px box + 12.5px `--text-muted` label.

### 6. Result grid + detail rail (Results zone)
- Grid of tiles on the bare canvas, `border-radius:10–12`, `1px --border`.
- Selection = 1px `--accent` border + `0 0 0 2px var(--accent-soft)` ring.
- Optional right-hand detail rail: a `--surface` card (the ONE card allowed in
  the results zone) with the focused item + its actions.

---

## Screens / views

For each screen: map the existing file, remove the hero / `.main-surface` wrap,
put the purpose in a work-panel, drop results onto the canvas.

### Image Studio — `apps/web/src/screens/ImageStudio.jsx`
- **Purpose (work-panel):** underline tabs `Text · Edit · With character` on a
  shared baseline, with `Prompt guide` / `Saved presets` links on the right;
  prompt field + filled **Generate** button (same height); "Try" suggestion
  chips; a 3-up "Prompt tools" tile row (Image reference / Prompt from image /
  Refine my prompt); a control row of `Model / Aspect / Variations / Style
  preset`.
- **Advanced (section below panel):** Negative prompt (full width), then a grid
  of Steps · Guidance · Guidance method · Seed · Sampler · Scheduler · Scheduler
  shift · Width×Height; LoRAs row; toggles Flash attention / Enhance prompt /
  bf16 precision. (These are the real state fields in `ImageStudio.jsx`.)
- **Results:** "Latest batch" label + variation tiles with Favorite / Reject.
- Today this screen uses `.surface-header.hero.studio-prompt-hero` — replace with
  the work-panel.

### Assets (Library) — `apps/web/src/screens/LibraryScreen.jsx`
- **Purpose (work-panel):** filled **Import**; `type` + `tag` selects; `Rejected`
  checkline; `Assets / Trashcan` segmented toggle; a compact stat strip
  (Assets total · Images · Clips) as small inset chips.
- **Results:** asset grid + the detail rail (thumbnail, name, `Send to Image /
  Video / Editor`, tags). Detail rail is the allowed results-zone card.
- Today uses `.surface-header.hero` + `.hero-stats` + wrapping `.main-surface` —
  remove the hero and the outer card.

### Queue — `apps/web/src/screens/QueueScreen.jsx`
- **Purpose (work-panel):** the job composer (Prompt input + GPU select + filled
  **Add job**) on one aligned row; a divider; the Project filter select.
- **Results:** GPU worker cards (Available / Memory / Load + meters, warm model)
  then the job list (`WorkerProgressCard` rows).
- Today uses a bespoke `.queue-header` (eyebrow + h2 + inline form) — replace with
  the work-panel; the `.queue-tools` filter folds into it.

### Logs — `apps/web/src/screens/LogsScreen.jsx`
- **Purpose (work-panel):** the filter toolbar becomes Logs' first real header —
  Source segmented (All / api / worker / mlx-worker), Level segmented
  (All / info / warn / error), search field, and the `● Live` toggle.
- **Results:** the log stream. Rows: mono time · source chip · level chip ·
  message; highlight routing events (`gpu_route_decision`,
  `claim_lock_contention`) with an accent-tinted row (`.highlighted` already
  exists). `warn`/`error` levels tint their chip with `--warn` / `--danger`.
- Today Logs has **no page header at all** (jumps straight to `.logs-toolbar`) —
  this is the biggest consistency win.

### Model Manager — `apps/web/src/screens/ModelManagerScreen.jsx`
- **Purpose (work-panel):** the `.mode-tabs` tab bar `Image · Video · Utility ·
  LoRAs` (with counts) + the `Search models` field on the right, **and** the
  curated **Recommended** picks (eyebrow + count + caption + the 3 recommended
  cards) — all inside the panel.
- **Results:** the "All <type> models" section heading + the full card grid.
- Model card: name; type/family chips; size + min-memory in mono; one action
  (Download / Manage / "N tiers" / gated → "Add token"). Gated models show a
  `--warn` "GATED" badge + the credential notice.
- Already uses `.models-surface` + `.mode-tabs`; keep the tabs, move the tab bar
  into the work-panel, and pull Recommended inside it.

### Data Sets (bonus) — `apps/web/src/screens/TrainingStudio.jsx` (`TrainingDataSetsLibrary`)
- The flagged "horrendous" row: dataset name field, character select, and ~5
  same-weight buttons (Import / Add / Caption all / Apply ordered names / Save)
  crammed on one line.
- **Fix (work-panel):** row 1 = the two inputs on an aligned labelled row + the
  single filled **Save dataset** CTA on the right; row 2 (below a divider) = the
  utility actions grouped and de-emphasized (`--surface-2` buttons), with a live
  "N images · M captioned" count. All controls on `--control-h`.

---

## Interactions & behavior (unchanged from today)
This is a visual/structural refactor — existing behavior stays:
- Tabs switch panels; the active tab gets the accent underline.
- Advanced is collapsible (persist open/closed as today via `saved.advancedOpen`).
- Generate / Add job / Download queue jobs; Favorite/Reject and Send-to-* keep
  their handlers.
- Logs polls every 2s and stays live-scrolled unless paused; search filters
  client-side.
- Hover: `--surface-hover`; focus: `border-color:var(--accent)` +
  `--shadow-glow`.
- Keep `[data-theme]` (light/dark) and `[data-accent]` palette switching working
  against the same markup.

## State management
No new global state. Local UI state that already exists per screen (active tab,
advanced-open, filter/search values, selection) is unchanged. If you build shared
`<PageFrame>` / `<WorkPanel>` components, they are presentational (children +
optional eyebrow/actions) — no state.

## Suggested implementation order
1. Add `--control-h` + the control-height CSS block to `styles.css` (global win,
   low risk). Add a shared caret asset for selects.
2. Introduce `<PageFrame>` (topbar-aware layout) + `<WorkPanel>` (accent-top-rule
   card) presentational components.
3. Migrate screens one at a time in this order: **Logs** (no header today →
   clearest win), **Queue**, **Assets**, **Model Manager**, **Image Studio**
   (+ its Advanced), **Video Studio**, then Data Sets. As you touch each, sweep
   every visible control onto `--control-h`.
4. Delete `.surface-header.hero` (+ orb) and the whole-page `.main-surface` wrap
   as screens are migrated; remove them from `styles.css` once no screen uses
   them.

## Assets
- **Logo:** `apps/web/src/components/Logo.jsx` (scene-cut mark, theme-aware) and
  `logo-large.png` at repo root — use the existing component; do not redraw.
- **Icons:** the app's existing `apps/web/src/components/Icons.jsx`. The line
  icons in the prototypes are placeholders — use the real icon set.
- **Caret for selects:** supply one small SVG (a chevron in `--text-faint`); none
  is bundled here.
- Image tiles in the prototypes are striped placeholders — use the app's real
  asset/thumbnail components.

## Files in this bundle
- `SceneWorks Frame Spec.dc.html` — **authoritative spec**: anatomy, tokens,
  components (incl. the control-height fix), and 1b applied to Queue / Logs /
  Model Manager.
- `SceneWorks Frame Standard.dc.html` — option exploration (1a flat bar / 1b
  work-panel / 1c hero) on Image Studio + Assets, plus the Data Sets header fix
  and a "1c with Advanced open" study. Context for why 1b was chosen.
- `support.js` — runtime so the two `.dc.html` files render when opened directly.

All specified values are sourced from `apps/web/src/styles.css` and the screen
components under `apps/web/src/screens/` in the SceneWorks repo.
