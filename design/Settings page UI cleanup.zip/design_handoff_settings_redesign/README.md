# Handoff: Settings screen redesign (SceneWorks advanced UI)

## Overview

The advanced (non-Simple) **Settings** screen in `apps/web/src/screens/SettingsScreen.jsx` is
visually out of step with the rest of the app: it renders a flat stack of `.settings-card`
sections with unstyled native buttons (the global reset strips `background`/`border`/`padding`,
and no `.settings-card button` rule exists), bulleted `<ul>` credential lists, and no page
margin — it is the only screen that is not built on the `.page-frame` / `.work-panel`
standard.

This redesign rebuilds it with the visual vocabulary of the Simple-mode Settings screen
(`apps/web/src/simple/SimpleSettings.jsx` + `simple/simple.css`), inside the app's standard
page shell, and organises it into four tabs so the page stops being one long scroll.

It also **adds the settings that only existed in Simple mode** to the advanced screen:
theme, accent, engine/GPU readout, and "Use Simple mode by default".

## About the design files

The files in this bundle are **design references authored in HTML** (`*.dc.html` — a single
streaming HTML component format; `support.js` is its tiny runtime). They are prototypes that
show the intended look, structure, and behavior. **They are not production code to copy.**

The task is to recreate this design **in the existing SceneWorks web app**: React 18 + Vite,
plain `.jsx` components under `apps/web/src/`, styling via the global `apps/web/src/styles.css`
using the existing CSS custom properties and class vocabulary. Reuse the existing components
and classes named below rather than introducing new ones — nearly every visual element in the
design already has a class in `styles.css` or `simple/simple.css`.

Open the HTML files in a browser to inspect exact spacing/behavior; every value below is also
written out.

## Fidelity

**High fidelity.** Colors, type, spacing, radii, and shadows are the app's own tokens, taken
from `apps/web/src/styles.css`. Recreate pixel-for-pixel using the existing classes; do not
invent new colors or spacing.

---

## Target implementation shape

Replace the body of `SettingsScreen.jsx`'s returned markup. All existing handlers, Tauri
`invoke` calls, REST calls, and state stay exactly as they are — this is a presentation change
plus four new settings.

```
<section className="page-frame settings-screen">      // replaces the bare .settings-screen div
  <WorkPanel className="settings-work-panel">         // components/WorkPanel.jsx (accent top-rule)
    <div className="prompt-hero-top">                 // existing class: tab row
      <ModeTabs label="Settings section" … />         // screens/generationStudio.jsx
    </div>
    {tab === "appearance" ? <AppearanceTab/> : null}
    {tab === "settings"   ? <StorageAndCredentialsTab/> : null}
    {tab === "device"     ? <DeviceTab/> : null}
    {tab === "server"     ? <ServerTab/> : null}
  </WorkPanel>
</section>
```

Notes:

- `.settings-screen`'s current CSS (`max-width: 44rem`, `gap: var(--gap-md)`) should be
  replaced with `max-width: 780px` on the page-frame; `.settings-card` and its helper classes
  (`.settings-actions`, `.settings-value`, `.settings-list`, `.settings-credential-form`,
  `.settings-gpu-cap`, `.settings-status`) become unused for this screen.
- `ModeTabs` already renders `<div className="mode-tabs" role="tablist">` +
  `<button className="mode-tab active">`, which is exactly the studio tab treatment. Wrap it in
  `.prompt-hero-top` so the tablist is a content-width flex item (its 1px baseline must NOT span
  the full panel width — this is what makes it read the same as Image Studio).
- Tab state: `const [tab, setTab] = useState("appearance")`. Not persisted (the screen is
  short-lived); if you want it sticky, mirror the existing `lastTierStore` localStorage pattern.
- The **Server** tab renders only when `isDesktop && remote` (same condition that gates today's
  Remote-access card). If `tab === "server"` and that becomes false, fall back to `"appearance"`.
- The **GPU memory** group renders only when `gpu?.platform === "macos" && gpu?.unifiedMemoryMb`
  (today's condition). **This machine** and **Maintenance** always render.
- Today's `status` string (`setStatus(...)`) currently renders as `.settings-status` at the top of
  the page. In the redesign there is no top status band — surface it the way Simple mode does,
  via a transient toast (`SimpleUiContext`'s `toast()` / `.su-toast`), or keep a single
  `.settings-status` line directly under the tab row. Pick one; do not reintroduce the
  full-width band above the panel.

---

## Screens / Views

There is **one screen** with **four tabs**. Everything is a single vertical column — no
multi-column grids.

### Shared chrome (unchanged, shown in the mocks for context only)

- `.app` grid: `232px` sidebar + `minmax(0,1fr)` workspace, `height: 100vh`, `overflow: hidden`.
- `.sidebar` (`--bg-2`, right hairline `--border`) — Settings is the active `.nav-item` in the
  **System** group.
- `.topbar`: `padding: 12px 22px`, `border-bottom: 1px solid var(--border)`, sticky, `z-index: 5`.
  Title `Settings` at 17px/600; the blurb comes from `viewTitles.Settings` in `App.jsx`.
  **Recommended copy change** (optional): blurb → “Appearance, generation defaults, storage,
  credentials and this machine.” (today: “Paths, service tokens, and detected GPU.”).
  **The tabs must not live in the topbar** — its height must stay identical to every other screen.

### The one panel

`.work-panel`: `position: relative`, `display: flex; flex-direction: column; gap: var(--gap-3)`
(14px), `padding: var(--pad-panel)` (20px), `background: var(--surface)`,
`border: 1px solid var(--border)`, `border-radius: var(--r-lg)` (16px),
`box-shadow: var(--shadow-md)`, plus the `.work-panel-rule` 3px accent gradient across the top.
Page frame margins: `20px 22px 30px`, `max-width: 780px`.

### Tab bar

`.prompt-hero-top` row → `.mode-tabs` (`display: flex; flex-wrap: wrap;
border-bottom: 1px solid var(--border)`) → `.mode-tab` buttons:
`padding: 11px 2px; margin-right: 26px; margin-bottom: -1px; font-size: 14px; font-weight: 500;
color: var(--text-muted); border-bottom: 2px solid transparent`.
Active: `font-weight: 700; color: var(--text); border-bottom-color: var(--accent)`.
Labels, in order: **Appearance · Settings · Device · Server**.

### Group + row vocabulary used inside every tab

| Element | Spec |
| --- | --- |
| Group label | 11px / 700 / `letter-spacing: .07em` / uppercase / `--text-faint` (same as `.su-group-title`) |
| Group separator | `.work-panel-divider` — `height: 1px; background: var(--border)` |
| Row | `display: flex; align-items: center; justify-content: space-between; gap: 12px` |
| Row title | 14px / 500 / `--text` (`.su-card-title`) |
| Row sub | `margin-top: 2px`; 11.5px / `--text-muted` (`.su-card-sub`) |
| Body copy | 11.5px / `line-height: 1.5` / `--text-muted` (`.su-card-note`) |
| Key–value row | `display: flex; justify-content: space-between; gap: 12px; font-size: 13px`; key `--text-muted`, value 500 right-aligned (`.su-kv`) |
| Inset block | `padding: 13px; border: 1px solid var(--border); border-radius: var(--r-md); background: var(--surface-2)` |
| Mono values | `font-family: var(--font-mono)`, 11.5–13px |

Controls (all already exist in `simple/simple.css` — reuse the `.su-*` classes or port them into
`styles.css` under settings-scoped names):

| Control | Class | Spec |
| --- | --- | --- |
| Segmented (Light/Dark) | `.su-theme-toggle` | wrapper `padding: 3px; border: 1px solid var(--border); border-radius: var(--r-sm); background: var(--bg-2)`; button `padding: 6px 12px; border-radius: var(--r-xs); font-size: 12.5px`; active `background: var(--surface); font-weight: 700; box-shadow: var(--shadow-sm)`; 14px leading icon (`Icon.Sun` / `Icon.Moon`) |
| Accent swatch | `.su-accent-swatch` | `30×30px; border-radius: 9px; border: 2px solid var(--border)`; active `border-color: transparent; box-shadow: 0 0 0 3px color-mix(in oklch, var(--accent) 35%, transparent)`; row `gap: 11px`, `flex-wrap: wrap`; colors from `ACCENTS[].swatch` in `accents.js` |
| Quality chips | `.su-chips` / `.su-chip` | row `gap: 6px; max-width: 320px`; chip `flex: 1; height: 34px; border: 1px solid var(--border); border-radius: var(--r-sm); background: var(--surface); color: var(--text-muted); font-size: 13px; font-weight: 500`; active `border-color: var(--accent); background: var(--accent-soft); color: var(--accent-strong); font-weight: 700` |
| Toggle switch | `.su-toggle` | `46×27px; border-radius: var(--r-pill); background: var(--border-strong)`; on → `var(--accent)`; knob `21×21px` white circle, `top: 3px`, `left: 3px` → `left: 22px`, `box-shadow: var(--shadow-sm)`, `transition: left var(--t-fast) var(--ease-out)` |
| Secondary button | `.su-row-action` | `min-height: 34px; padding: 0 14px; border: 1px solid var(--border); border-radius: var(--r-sm); background: var(--surface); font-size: 12.5px; font-weight: 600`; hover `background: var(--surface-hover)` |
| Destructive-ish button | `.su-job-cancel` | as above but `color: var(--text-muted)`; hover `border-color: color-mix(in oklch, var(--danger) 45%, var(--border)); color: color-mix(in oklch, var(--danger) 75%, var(--text))` |
| Primary button | `.su-accent-btn` | `min-height: 38px; padding: 0 15px; border: 0; border-radius: var(--r-sm); background: var(--accent); color: var(--accent-fg); font-size: 13px; font-weight: 600`; disabled `opacity: .55` |
| Text input | `.su-input` | `height: var(--control-h)` (38px); `padding: 0 11px; border: 1px solid var(--border); border-radius: var(--r-sm); background: var(--surface); font-size: 13px`; focus = the app's global `border-color: var(--accent); box-shadow: var(--shadow-glow)` |
| Warning notice | `.su-notice` | `display: flex; gap: 9px; padding: 11px 13px; border: 1px solid color-mix(in oklch, var(--warn) 40%, var(--border)); border-radius: var(--r-md); background: var(--warn-soft)`; 16px `Icon.Warning` in `--warn`; text 11.5px/1.45 `--text-muted` |
| Range slider | native `input[type=range]` | `width: 100%`, `accent-color: var(--accent)`, `min=10 max=100 step=5` |
| Credential row | `.su-row` | `display: flex; align-items: center; gap: 12px; padding: 11px; border: 1px solid var(--border); border-radius: var(--r-md); background: var(--surface-2)`; 40×40 `.su-row-glyph` (`border-radius: var(--r-sm)`, `background: var(--accent-soft)`, `color: var(--accent-strong)`, 18px icon) + text block (host 13px/500 mono, meta 11.5px `--text-muted`) + Remove button |

---

### Tab 1 — Appearance

Screenshot: `screenshots/01-appearance-tab.png` (dark: `05-appearance-dark.png`)

**Group THEME**
1. Row — title `Mode`, right: Light/Dark segmented control.
   Wired to the existing `changeTheme` from `AppContext` (same durable
   `PUT /api/v1/ui-preferences` path the topbar toggle uses). **New on this screen.**
2. Row — title `Accent`, sub `Recolors the whole app — chips, buttons, the mark.`,
   right: seven accent swatches from `ACCENTS` (`accents.js`), wired to `changeAccent`.
   **New on this screen.**

**Group SIMPLE MODE**
3. Row — title `Use Simple mode by default`, sub
   `Phones always use it; the sidebar switch overrides it for this session.`
   (when locked to Simple: `Phones always use it.`), right: toggle.
   Wired to the `simpleUiDefault` / `setSimpleUiDefault` pair in `App.jsx` (the same value
   Simple Settings writes). **New on this screen.**

**Group GENERATION**
4. `Default quality` title, then the four chips `Auto · bf16 · Q8 · Q4`
   (`GENERATION_QUALITY_OPTIONS`; short labels via `shortQualityLabel()` from
   `SimpleSettings.jsx`, full label on `title`), then a sub line showing
   `generationQualityLabel(value)` (e.g. `Auto (best that fits this Mac)`), then the note:

   > The tier new generations use for a model you haven’t picked one for yet. **Auto** takes the
   > highest-fidelity tier that fits this machine for each model. Per-model picks in a studio
   > always win, and are remembered.

   Replaces today's `<select>`; keeps `changeDefaultQuality` verbatim.

### Tab 2 — Settings

Screenshot: `screenshots/02-settings-tab.png`

**Group STORAGE** (desktop only)
1. `Data directory` + sub `Projects, generated assets, models and LoRAs. Moving it needs a restart.`
2. Mono path in an inset block: `padding: 9px 11px; border-radius: var(--r-sm);
   background: var(--surface-2); font-size: 11.5px; overflow-wrap: anywhere`.
   Value: `settings?.dataDir ?? "Default location"`.
3. Buttons row (`gap: 8px`): `Change…` (`changeDataDir`), `Reveal in Finder` /
   `Reveal in Explorer` (`revealDataDir`, disabled without `settings?.dataDir`).

**Group SERVICE CREDENTIALS**
4. Note: `API tokens for model & LoRA downloads — Hugging Face, Civit.ai, any authenticated
   source. Stored in {credentialLocation}. Tokens are write-only: never shown again after
   saving, and a change takes effect on the next worker restart.`
   (`credentialLocation` = today's derived string: system Keychain / Windows Credential Manager /
   Secret Service / the server's credential store.)
5. One `.su-row` per credential: glyph (`Icon.Model`, accent-soft) — or, when
   `credential.present === false`, `Icon.Warning` on `--warn-soft`/`--warn`; host in mono;
   meta line `{label · }{SCHEME_LABELS[scheme]}{ · token missing}`; `Remove` button
   (`removeCredential(host)`). Empty state: the note line `No credentials saved.` at 11.5px muted.
6. `Add a token` inset block: two-up host + label inputs
   (`grid-template-columns: 1fr 1fr; gap: 8px`), then a two-chip scheme selector
   (`Bearer header` / `Query token`) replacing the `<select>`, then a row with the password-type
   token input (`flex: 1`) and the accent `Add` button, disabled until host + token are non-empty.
   Handler: existing `addCredential`.

### Tab 3 — Device

Screenshot: `screenshots/03-device-tab.png`

**Group THIS MACHINE** — three key–value rows:
- `Engine` → `MLX · Apple Silicon` / `Candle · discrete GPU` / `Detecting…`
- `GPU` → `{gpuName} · {memory} GB` or `No worker connected`
- `Unified memory` → `128 GB · system cap 96 GB` (macOS only; from `gpu.unifiedMemoryMb` /
  `gpu.wiredLimitMb`)

Derive Engine/GPU with `describeDevice(visibleWorkers, macCapabilities)` — already exported from
`simple/SimpleSettings.jsx`; move it to a shared module and use it in both screens. The old
`Detected GPU` bulleted `<ul>` of `gpu.devices` is replaced by these rows. **New on this screen.**

**Group GPU MEMORY** (macOS only)
- Header row: title `Memory target` on the left, live value on the right at 12.5px/600 in
  `--accent-strong`: `~96 GB of 128 GB (75%)`, or `Use all available` at 100%.
- Range slider (`min 10`, `max 100`, `step 5`), `margin-top: 11px`. Commit on
  mouseup/keyup/touchend exactly as today (`commitGpuMemoryLimit`); `100 → null`.
- Under it, a `10%` / `Use all available` scale line at 10.5px `--text-faint`,
  `justify-content: space-between`.
- Note (11.5px muted): `A soft target for how much unified memory SceneWorks holds, so more stays
  free for the rest of your system. Not a hard limit — large models can still exceed it. Applies
  within a couple of seconds, no restart.` followed inline by
  `sudo sysctl iogpu.wired_limit_mb=<bytes>` in a `<code>` chip
  (`background: var(--surface-2); padding: 1px 5px; border-radius: var(--r-xs)`) and
  ` raises the system cap on 96/128 GB Macs.`
- `LIVE MLX MEMORY` inset block with three mono key–value rows: `Active`, `Peak`, `Limit`
  (from the 2s `get_gpu_telemetry` poll; render the block only when `gpuTelemetry` exists).

**Group MAINTENANCE**
- Row `Inference worker` / sub `Restart to pick up credential changes or clear a stuck job.` →
  `Restart` button (`restartWorker`).
- Row `Setup wizard` / sub `Re-open the guided setup to download more models or create a project.`
  → `Re-run` button (`rerunSetupWizard`), desktop only.

### Tab 4 — Server

Screenshot: `screenshots/04-server-tab.png` — desktop only, gated on `remote`.

**Group REMOTE ACCESS (LAN)**
1. Row `Let other devices on this network in` / sub `Generation still runs on this computer.
   Takes effect after a restart.` → toggle. On/off calls `applyRemoteAccess(true|false)`;
   disabled (with the existing `Set a password before enabling remote access.` guidance) when
   `!remote.passwordSet`. Replaces the Enable/Disable buttons.
2. URL row: `remote.url` in mono 12.5px (`flex: 1`, ellipsis) + `Copy` button with
   `Icon.Duplicate` at 14px (`copyRemoteUrl`).
3. `Also reachable at {lanCandidates.slice(1).join(", ")}` at 11.5px muted (omit when there is
   only one candidate). When there is no URL, show today's copy:
   `Couldn’t determine this computer’s LAN address — check your network connection.`
4. `ACCESS` inset block:
   - password input (`Set a password` / `Change password` placeholder) + `Save`
     (`saveRemotePassword`, disabled while blank) + `Clear` (`clearRemotePassword`, only when
     `remote.passwordSet`).
   - a row with `A password is set — remote browsers must enter it.` on the left and
     `Port` + a 96px-wide mono number input (1024–65535) right-aligned.
5. `.su-notice` warning: `Trusted local networks only. Traffic is plain HTTP, so the password and
   your content travel unencrypted — never port-forward this or expose it to the internet.`
   plus the platform firewall sentence (macOS: `The first time SceneWorks binds the port, macOS
   may ask to allow incoming connections — click Allow.`; Windows: `The first time SceneWorks
   binds the port, allow it on Private networks in the Windows Security prompt.`).
   This consolidates today's three separate `.settings-help` / `.settings-muted` paragraphs.

---

## Interactions & Behavior

- **Tabs**: click switches the panel body; no animation. Keep `role="tablist"` / `role="tab"`
  and add `aria-selected` (ModeTabs already does).
- **Theme / accent**: apply immediately (they set `data-theme` / `data-accent` on the root, so the
  whole app recolors live) and write through `PUT /api/v1/ui-preferences`.
- **Quality chips / toggles / scheme chips**: instant, optimistic; persistence unchanged.
- **GPU slider**: local state while dragging, commit on release (`onMouseUp`/`onKeyUp`/
  `onTouchEnd`) — today's behavior; the readout follows the drag.
- **Hover**: `.mode-tab:hover → color: var(--text)`; secondary buttons →
  `background: var(--surface-hover)`; Remove/Clear → danger-tinted border + text.
- **Focus**: keep the global `button:focus-visible { outline: 2px solid var(--accent);
  outline-offset: 2px }` and the input focus glow.
- **Transitions**: only the existing token-driven ones (`--t-fast` 120ms with `--ease-out`) on
  toggle background/knob and tab color. No entrance animations.
- **Responsive**: single column; the panel is capped at 780px and the tab row wraps
  (`flex-wrap: wrap`). No new breakpoints. Phones get the Simple shell, so no mobile work here.

## State Management

New local state on `SettingsScreen`: `tab` (`"appearance" | "settings" | "device" | "server"`).
Everything else already exists (`settings`, `gpu`, `gpuTelemetry`, `gpuLimitPercent`,
`credentials`, `newHost`/`newLabel`/`newScheme`/`newToken`, `remote`, `remotePort`,
`remotePassword`, `defaultQuality`, `status`).

Newly consumed from `AppContext` / `App.jsx`: `theme`, `changeTheme`, `accent`, `changeAccent`,
`visibleWorkers`, `macCapabilities`, and the Simple-UI default pair (`simpleUiDefault`,
`setSimpleUiDefault`, plus `uiModeLocked` for the copy variant). No new endpoints.

## Design Tokens

All from `apps/web/src/styles.css` — do not hardcode.

Type: `--font-ui` "Plus Jakarta Sans", `--font-mono` "JetBrains Mono".
Sizes in use: 17 (topbar h1), 14 (row title / tab), 13 (kv, inputs, chips), 12.5 (secondary
button, topbar blurb), 11.5 (sub / note), 11 (group label, uppercase), 10.5 (scale line).

Radii: `--r-xs` 6, `--r-sm` 8, `--r-md` 12, `--r-lg` 16, `--r-pill` 999.
Spacing: `--gap-3` 14 (panel gap), `--pad-panel` 20, `--control-h` 38; page frame gap 18,
group gap 10–14, row gap 8–12, screenshot margins `20px 22px 30px`.

Color (light): `--bg` `oklch(.985 .005 240)`, `--bg-2` `oklch(.965 .008 240)`,
`--surface` `#fff`, `--surface-2` `oklch(.97 .006 240)`,
`--surface-hover` `oklch(.955 .01 240)`, `--border` `oklch(.91 .01 240)`,
`--border-strong` `oklch(.84 .012 240)`, `--text` `oklch(.22 .012 240)`,
`--text-muted` `oklch(.5 .012 240)`, `--text-faint` `oklch(.66 .01 240)`.
Accent is hue-driven: `--accent oklch(.66 .11 var(--accent-h))`,
`--accent-strong oklch(.55 .13 …)`, `--accent-soft oklch(.94 .04 …)`, `--accent-fg #fff`;
default `--accent-h: 178` (teal). Status: `--warn`, `--warn-soft`, `--danger`, `--danger-soft`,
`--success`. Dark overrides come from `[data-theme="dark"]` — the design needs no dark-specific
work beyond using the tokens (see `05-appearance-dark.png`).

Shadows: `--shadow-sm` (toggle knob, active segment), `--shadow-md` (the work-panel),
`--shadow-glow` (input focus).

Motion: `--t-fast` 120ms, `--t-med` 220ms, `--ease-out` `cubic-bezier(.22,1,.36,1)`.

## Assets

No new assets. All glyphs are existing entries in `apps/web/src/components/Icons.jsx`:
`Sun`, `Moon`, `Model`, `Warning`, `Duplicate` (copy), `Sliders` (nav), `ChevDown`, `Bell`.
The wordmark is `components/Logo.jsx`. Fonts are already self-hosted via `styles.css`
(`@font-face`); the mock loads them from Google Fonts only because it is standalone.

## Files

In this bundle:

- `Settings.dc.html` — the redesign (interactive: tabs, theme, accent, quality, toggles, slider).
  Tweakable props at the top of its `data-props` JSON: `theme`, `accent`, `platform`
  (`Desktop · macOS` / `Desktop · Windows` / `Server / remote browser`, which gates the
  desktop-only groups and swaps Finder/Explorer/keychain wording).
- `Settings — current (recreation).dc.html` — a faithful recreation of **today's** screen, for
  before/after comparison.
- `support.js` — runtime for the two HTML files (open them from this folder so it resolves).
- `screenshots/00-before-current-settings.png` — today's screen.
- `screenshots/01-appearance-tab.png`, `02-settings-tab.png`, `03-device-tab.png`,
  `04-server-tab.png`, `05-appearance-dark.png`.

In the SceneWorks repo (`SceneWorks/SceneWorks`, branch `main`):

- `apps/web/src/screens/SettingsScreen.jsx` — the screen to rewrite.
- `apps/web/src/simple/SimpleSettings.jsx` — source of the visual pattern, of
  `shortQualityLabel()` / `describeDevice()`, and of the four settings being brought over.
- `apps/web/src/simple/simple.css` — the `.su-*` control specs quoted above.
- `apps/web/src/styles.css` — tokens, `.page-frame`, `.work-panel`, `.mode-tabs`/`.mode-tab`,
  `.prompt-hero-top`, and the now-orphaned `.settings-*` rules (~line 13365).
- `apps/web/src/components/WorkPanel.jsx`, `apps/web/src/screens/generationStudio.jsx`
  (`ModeTabs`), `apps/web/src/components/Icons.jsx`, `apps/web/src/accents.js`,
  `apps/web/src/generationQuality.js`.
- `apps/web/src/screens/ImageStudio.jsx` (~line 2353) — the canonical
  `page-frame → WorkPanel → .prompt-hero-top → ModeTabs` arrangement this screen now follows.
- `apps/web/src/screens/SettingsScreen.test.jsx` — existing tests assert the old DOM
  (`.settings-card`, button labels like `Save token`, `Enable remote access`); they will need
  updating alongside the rewrite.
