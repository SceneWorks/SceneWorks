# Handoff: Data Sets page (focused redesign)

## Overview
A focused redesign of the SceneWorks **Data Sets** screen — the library where a user
builds and captions a training dataset before training a LoRA. The redesign applies the
project's **Page-Frame Standard**: the global topbar owns the page title + blurb, and the
screen body is a single **Purpose zone** (one accent-barred hero that holds everything up
to and including the Dataset Doctor) followed by a **Results zone** (the images + captions
grid).

This maps to the existing screen rendered by **`TrainingStudio` in `mode="datasets"`**
(exported as `TrainingDataSetsLibrary`), whose editor lives in
`apps/web/src/screens/training/DatasetEditorPanel.jsx`. The redesign reorganizes that
existing content — it does not add new backend features.

## About the Design Files
The files in this bundle are **design references created in HTML** — a prototype showing the
intended look and layout, not production code to copy directly. The task is to **recreate
this design inside the existing SceneWorks web app** (`apps/web`, React + the tokens in
`apps/web/src/styles.css`), reusing its established components (`WorkPanel`, `CompactSelector`,
`Icon`, `DatasetDoctorReadout`, `AssetThumbnail`, etc.) and class-based CSS. Do **not** ship
the HTML/inline-styles directly.

`SceneWorks Data Sets.dc.html` is a "Design Component" — it renders standalone in a browser.
Its markup uses inline styles and CSS custom properties that **mirror `styles.css`** (prefixed
`--sw-*` here vs the app's real names). The mapping is 1:1; see **Design Tokens** below.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, radii, and states are all specified and
taken from `styles.css`. Recreate pixel-for-pixel using the app's existing tokens/classes.
The dataset content (names, captions, counts, flags) is placeholder sample data. Thumbnails
are striped placeholders standing in for real `AssetThumbnail` renders.

## Screens / Views

### Data Sets (single screen, two display states)
The `nameState` tweak in the prototype demonstrates two states of the same screen:
**`saved`** (editing an existing dataset) and **`new`** (a fresh draft).

**Purpose:** Name a dataset, add/caption images, review readiness (Dataset Doctor), and save.

**Layout (top → bottom):**
1. **Topbar** (global chrome — already exists in `App.jsx`; do not rebuild). Left: page title
   `Data Sets` + blurb `Create and caption training datasets.` Right: the dataset
   `CompactSelector` pill, a `Refresh` button, a divider, and the user avatar dot.
2. **Purpose hero** — one rounded panel (`--r-xl` = 22px) on `--surface-2`, with a 3px
   `--accent` bar down the left edge, `padding: 20px 24px 20px 26px`. Contains, separated by
   1px `--border` hairlines:
   - **Identity + primary CTA row** (`display:flex; justify-content:space-between; gap:24px; flex-wrap:wrap`)
   - **Tools row** (`Name prefix` field + `Add images` / `Caption all` / `Apply ordered names`)
   - **Health rail** (`display:grid; grid-template-columns: repeat(3,1fr) auto; gap:12px`)
   - **Dataset Doctor band** (full-width; header line + full-width progress bar)
3. **Results zone** — section header (`Images & captions` + `All/Missing/Flagged` segmented
   control + count) then a **3-column grid** (`repeat(3,1fr); gap:14px`) of caption cards.

**Components:**

- **Topbar title/blurb** — `h1` 17px/600, `-0.01em`; blurb 12.5px `--text-muted`.
- **Dataset selector (`CompactSelector`)** — pill: 32px cover thumb (rounded 8px), name
  13px/600, subtitle 11px `--text-muted` (`"24 items · Person"`), chevron. Opens a menu whose
  first item is **New dataset** (`onCreate` → `startNewDataset`). This is the primary
  create entry point — there is intentionally **no** separate "New" button.
- **Refresh button** — secondary button, 34px tall, `Icon.Search`/refresh glyph + label.
- **Eyebrow** — `Build & caption`, 10px/700, `.11em`, uppercase, `--accent-strong`.
- **Dataset name field** — the hero's most prominent element.
  - *saved state:* borderless text input, 22px/600, `-0.01em`, `--text`, transparent bottom
    border; **a 28px square pencil button** (`--border` outline, `--surface`, `--text-muted`)
    sits immediately to its right to signal it's renameable.
  - *new state:* a **boxed input** — 18px/600, `--surface` bg, 1px `--border`,
    `border-radius:11px`, `padding:11px 15px`, placeholder `"Name this dataset…"`.
  - A character chip sits to the right in both states: `Person · Aurora`, 11.5px `--text-muted`,
    pill (`--r-pill`), 1px `--border`, `--surface` bg.
- **Description line** — 13px `--text-muted`, `max-width:62ch`, contains a link to
  Training Studio (`a` = `--accent`).
- **Status pill** (top-right of hero):
  - *saved:* `Unsaved changes` — 11.5px/600 `--warn` on `--warn-soft`, with a 7px warn dot.
    (When there are no pending edits the real app shows `Version {n}` instead.)
  - *new:* `Draft` — neutral, `--text-muted` on `--surface`, 1px `--border`.
- **Primary CTA** — `Save dataset` (saved) / `Create dataset` (new). Accent-filled,
  `--accent-fg` text, 14px/700, `border-radius:11px`, `padding:11px 22px`, save-glyph icon,
  accent glow shadow. Disabled until `canSave`.
- **Tools row buttons** — `Name prefix` labeled field (mono 13px, 36px tall) on the left;
  `Add images` (primary-weight secondary), `Caption all`, `Apply ordered names` on the right.
- **Health rail tiles** — 3 stat tiles (`--surface`, 1px `--border`, `--r-md`): value 22px/700,
  label 11.5px `--text-muted`. `Items`, `Missing captions` (border + value tint `--warn` when
  > 0), `Duplicate filenames`. A 4th wide tile holds a status dot + sentence
  (`Almost ready — clear the flags below to train.`).
- **Dataset Doctor band** — full width. Header line: 34px rounded accent-soft icon tile,
  `Dataset Doctor` 13.5px/600, `22 of 24 items ready` 12px `--text-muted`, a flex spacer, then
  flag chips (`2 low-resolution` on `--warn-soft`; `1 near-duplicate` neutral) and a
  `Re-caption flagged` button pushed to the right. Below: a full-width 6px progress track
  (`--bg`) with an `--accent` fill (92%). Maps to `DatasetDoctorReadout`.
- **Results header** — eyebrow `Results` + `h2` `Images & captions` (16px/600); right side:
  count `24 images · 22 captioned` + segmented control `All / Missing / Flagged`.
- **Caption card** — `--surface`, 1px `--border`, `--r-lg` (16px ≈ prototype 14px),
  `padding:12px`, **`display:grid; grid-template-columns:1fr 1fr; gap:12px`**:
  - *Left half:* the image thumbnail (`AssetThumbnail`), fills the half, `border-radius:10px`,
    `min-height:150px`, `object-fit:cover`. A small readiness badge overlaps top-right (18px
    circle: `--success` ✓ ready / `--warn` ! flagged). This large thumbnail is the key change —
    images occupy half the card.
  - *Right half:* filename 12.5px/600 (ellipsis); source badge (`Manual` neutral / `Auto`
    accent-soft / `Imported` faint), 10px/700 uppercase; optional flag chip (`--warn`);
    caption textarea (12px/1.5, `--bg`, 1px `--border`, `--r-sm`, `min-height:56px`; empty =
    dashed warn border + italic placeholder `Describe this image…`); and a bottom-aligned
    action row `Remove` / `Re-Caption` (`margin-top:auto`).

## Interactions & Behavior
- **Create:** `CompactSelector` → "New dataset" resets the editor to a draft (empty name field
  in boxed style, `Draft` status, `Create dataset` CTA, zeroed health).
- **Rename:** the pencil button focuses the name input.
- **Add images:** opens `DatasetAddDialog` (`setAddDialogOpen(true)`).
- **Caption all / Re-Caption / Re-caption flagged:** open `DatasetCaptionDialog` with scope
  `all` / `item` / `flagged`.
- **Apply ordered names:** batch-rename members using the prefix (`applyOrderedNames`).
- **Filter segmented control** (`All/Missing/Flagged`): client-side filter of the card grid.
- **Save/Create:** disabled until `canSave`; label follows draft vs existing.
- Transitions use `--t-fast` (120ms) / `--t-med` (220ms) with `--ease-out`
  (`cubic-bezier(0.22,1,0.36,1)`), matching the rest of the app.

## State Management
Owned by the `TrainingStudio` screen (already implemented) and passed into
`DatasetEditorPanel`. Relevant pieces: `datasets`, `activeDataset`, `selectedDatasetId`,
`draftName`, `renamePrefix`, `dirty`, `savingDataset`/`canSave`, `memberAssets`,
`captionDraftById`, `datasetDoctor` (readiness report + fix callbacks), `readinessByKey`,
`addDialogOpen`, `captionDialog`. Data comes from `useTraining.js`
(`refreshTrainingDatasets`, `loadTrainingDataset`, `loadTrainingDatasetReadiness`,
`updateTrainingDataset`, `uploadTrainingDatasetItem`, caption/analysis jobs). No new state is
introduced by the redesign.

## Design Tokens
Prototype var → real `styles.css` var (use the real ones):

| Prototype | styles.css | Value (dark) |
|---|---|---|
| `--sw-bg` | `--bg` | `oklch(0.165 0.012 240)` |
| `--sw-bg2` | `--bg-2` | `oklch(0.145 0.012 240)` |
| `--sw-surface` | `--surface` | `oklch(0.205 0.012 240)` |
| `--sw-surface2` | `--surface-2` | `oklch(0.235 0.014 240)` |
| `--sw-hover` | `--surface-hover` | `oklch(0.255 0.014 240)` |
| `--sw-border` | `--border` | `oklch(0.285 0.014 240)` |
| `--sw-border2` | `--border-strong` | `oklch(0.36 0.016 240)` |
| `--sw-text` | `--text` | `oklch(0.96 0.008 240)` |
| `--sw-muted` | `--text-muted` | `oklch(0.72 0.012 240)` |
| `--sw-faint` | `--text-faint` | `oklch(0.56 0.012 240)` |
| `--sw-accent` | `--accent` | `oklch(0.74 0.11 var(--accent-h))` |
| `--sw-accent-strong` | `--accent-strong` | `oklch(0.82 0.12 …)` |
| `--sw-accent-soft` | `--accent-soft` | `oklch(0.30 0.06 …)` |
| `--sw-accent-fg` | `--accent-fg` | `oklch(0.16 0.012 240)` |
| `--sw-warn` / `--sw-warn-soft` | `--warn` / `--warn-soft` | `oklch(0.82 0.14 80)` / `oklch(0.33 0.07 70)` |
| `--sw-ok` | `--success` | `oklch(0.62 0.13 155)` |

- **Accent** is hue-driven (`--accent-h`); the prototype's `accent` tweak mirrors the app's
  seven palettes (teal 178 default, indigo 274, cobalt 252, violet 305, coral 28, amber 80,
  emerald 152). Recolor the whole screen by swapping `[data-accent]`, exactly as the app does.
- **Type:** `--font-ui` = Plus Jakarta Sans (400/500/600/700); `--font-mono` = JetBrains Mono.
- **Radius:** xs 6 / sm 8 / md 12 / lg 16 / xl 22 / pill 999.
- **Spacing:** gaps 6/10/14/20/28; `--pad-panel` 20.
- **Light theme** exists in `styles.css` (`:root` default is light; `[data-theme="dark"]`
  overrides). The prototype shows dark only; the recreation must honor both themes via tokens.

## Assets
- **Icons:** use the existing `apps/web/src/components/Icons.jsx` set (Plus, Sliders, Search,
  refresh, pencil, calendar/doctor). The prototype's inline SVGs are stand-ins.
- **Thumbnails:** real images render through `AssetThumbnail` — the striped boxes are
  placeholders only.
- No new image assets are required.

## Files
- `SceneWorks Data Sets.dc.html` — the hi-fi design prototype (this bundle).
- `support.js` — runtime for the prototype (lets the HTML open standalone; not for production).
- In the app, the screen to update:
  - `apps/web/src/screens/TrainingStudio.jsx` (`mode="datasets"` / `TrainingDataSetsLibrary`)
  - `apps/web/src/screens/training/DatasetEditorPanel.jsx`
  - supporting: `DatasetDoctor.jsx`, `DatasetAddDialog.jsx`, `DatasetCaptionDialog.jsx`,
    `components/CompactSelector.jsx`, `components/WorkPanel.jsx`, `hooks/useTraining.js`,
    tokens in `styles.css`.
