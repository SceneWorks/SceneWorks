# Handoff: Video Editor redesign (SceneWorks)

## Overview
A ground-up redesign of the SceneWorks **Video Editor** (`apps/web/src/screens/EditorScreen.jsx`).
The current editor is a cramped grid of numeric inputs where the AI features (extend, bridge,
generate-across-keyframes) are buried and the timeline is a set of absolutely-positioned buttons
with no ruler, playhead, or audio. This redesign is a **classic dark NLE** (Premiere/Resolve muscle
memory) with the AI generation features woven directly into the timeline, plus the full generation
control set from Video Studio brought into the editor.

The bundle contains **one delivered direction, `2a` ("Unified")**, plus two earlier explorations
(`1a` Classic Studio, `1b` Storyboard-Forward) kept for reference. **Implement `2a`.** `1a` and `1b`
are alternate arrangements of the same parts and can be ignored unless noted.

## About the Design Files
`Video Editor.dc.html` is a **design reference authored in HTML/JS** — an interactive prototype that
shows the intended look and behavior. It is **not production code to copy**. SceneWorks' web app is
**React + Vite** (`apps/web/`), styled with a single global stylesheet of CSS custom properties
(`apps/web/src/styles.css`). The task is to **recreate design `2a` as a React screen in that existing
environment**, reusing the app's real tokens, components, and the timeline data model that already
exists — not to ship the HTML.

Because this design targets an existing screen, most of what you need already exists in the repo:
- Screen to replace: `apps/web/src/screens/EditorScreen.jsx`
- Timeline data model + helpers: `apps/web/src/timeline.js` and `apps/web/src/hooks/useTimelines.js`
- App context (assets, timeline actions, generation): `useAppStatic()` in `apps/web/src/context/AppContext.js`
- Design tokens: `apps/web/src/styles.css` (`:root` and `[data-theme="dark"]`)
- Icons: `apps/web/src/components/Icons.jsx`
- The generation controls to mirror: `apps/web/src/screens/VideoStudio.jsx`

## Fidelity
**High-fidelity.** Final layout, colors, typography, spacing, and interactions. Recreate pixel-close
using the codebase's existing tokens and components. The one caveat: the editor is presented on a
**dark surface** (video tools convention) even though the app defaults to light — see "Theme" below.

---

## The design at a glance (`2a`)
Vertical stack inside one editor surface (authored at 1440 wide; real screen is fluid/full-bleed):

```
┌─ Toolbar ────────────────────────────────────────────────────────────────┐
│ project · undo/redo · [timecode / duration] · zoom -/+ · Export           │
├──────────────┬───────────────────────────────┬───────────────────────────┤
│  Media bin   │        Program monitor         │   GENERATION SETTINGS     │
│ (Media/      │   (16:9 preview + transport)   │   (contextual actions +   │
│  Assets tabs)│                                │    full Video-Studio form)│
├──────────────┴───────────────────────────────┴───────────────────────────┤
│  STORYBOARD strip  (key-image cards + "generate across" connectors)       │
├───────────────────────────────────────────────────────────────────────────┤
│  TIMELINE  (ruler+timecode, V2, V1, A1/A2/A3 with waveforms, playhead)     │
└───────────────────────────────────────────────────────────────────────────┘
```
Two structural decisions from the client: **the storyboard sits directly above the timeline**
(not at the top of the screen), and the **full generation settings** live in the right rail.

---

## Screens / Views

### View: Video Editor (single screen)

**Purpose:** Sequence image + video clips on a timeline, generate/extend/bridge video with AI, add
transitions and multiple audio tracks, and export to MP4.

**Layout:**
- Root: `display:flex; flex-direction:column`, dark surface, `--r-lg` (16px) corners in the mock; in
  the app it is full-bleed inside `.workspace` (no outer card/radius needed).
- **Toolbar** — `height:52px`, `flex` row, `padding:0 16px`, bottom `1px` border, `background:var(--bg-2)`.
  Left: app mark (24px rounded, teal→violet gradient) + project name (`13.5px/600`) and sub
  (`10.5px` mono, `--text-faint`). Center: current timecode (`19px/600` mono) + `/ duration`
  (`12px`, `--text-faint`). Right: zoom `–` / `%` / `+`, and a filled **Export** button
  (`height:34px`, `background:var(--accent)`, `color:var(--accent-fg)`, `--r-sm`).
- **Upper region** — CSS grid, `grid-template-columns: 168px minmax(0,1fr) 350px`, fills remaining height.
  - **Media bin** (168px): tab row ("Media"/"Assets"), 2-col grid of asset thumbnails
    (`aspect-ratio:16/10`, `--r-sm`, gradient placeholder, mono filename bottom-left, violet AI
    sparkle badge top-right for AI-generated assets).
  - **Program monitor** (center): radial-tinted background; a `16:9` preview
    (`max-width:640px`, `--r-md`, `object-fit:contain`) with an overlaid clip label (top-left, mono
    on `rgba(0,0,0,.35)`), an "AI clip" pill (top-right, violet) when the shown clip is AI, and a
    `1280 × 720` readout. Transport row below: prev / **play-pause** (46px teal circle) / next.
  - **Generation settings rail** (350px): see "Generation settings" section below.
- **Storyboard strip** — `flex:0 0 auto`, `padding:12px 16px 13px`, top border, subtle violet radial
  tint. Header: violet sparkle + "Storyboard" + hint + a done/generate legend. Body: horizontal
  scroll row of **key-image cards** (`132×96`, `--r-md`, gradient, timecode chip top-left, label
  bottom) separated by **connectors** — a thin rule with a pill: solid teal `▸ 1.8s` = generated,
  violet `＋ generate` / `generating…` = pending. Trailing dashed "+" card to add a key image.
- **Timeline** — `flex:0 0 auto`, top border. Header bar (`height:38px`): "TIMELINE" label,
  Clip/AI legend, Snap toggle, zoom `–`/`+`. Body is two columns:
  - **Track headers** (148px, non-scrolling): a 30px spacer aligned to the ruler, then one header
    per lane — **V2** (overlay), **V1** (main video), **A1/A2/A3** (audio). Video headers show an eye
    toggle; audio headers show **M**/**S** (mute/solo) and an AI sparkle on the AI music track.
  - **Lanes** (horizontal scroll): a content box whose width = `duration × pxPerSecond × zoom`.
    Everything inside is positioned by **percentage of duration**, so zoom only changes the content
    width. Contains: ruler, V2 lane, V1 lane, three audio lanes, and the playhead overlay.

**Components (detail):**

- **Ruler** — `height:30px`, `cursor:ew-resize`. Tick per second: minor tick from mid-height, major
  tick (every 5s) full-height with a mono `m:ss` label (`9.5px`, `--text-faint`). **Markers** render
  here as amber (`--warm`) flags with a small label pill ("Act 2", "Beat drop"), clickable. Mouse-down
  anywhere on the ruler scrubs the playhead (drag to continue).
- **Clip block** (V1/V2) — absolutely positioned (`left`/`width` as % of duration), `top/bottom:4px`,
  `--r-xs`+ (7px), gradient fill derived from a per-clip hue, `1px` light border. **Selected:**
  `1.5px solid var(--accent)` + double-ring box-shadow. **AI clips** additionally get a violet outline
  and a violet sparkle chip (top-right). Clip name is `11px/600` white with shadow, bottom-aligned.
  **Keyframe markers** inside an AI clip render as small rotated-square diamonds (violet, white
  border) at their relative time; clickable.
- **Transition badge** — a 22px teal circle centered on the cut between two clips (crossfade icon),
  `z-index` above clips.
- **Gap / AI bridge** — an empty span between clips shown as a dashed violet zone with a diagonal
  hatch and a "＋ Bridge" label; selecting it offers bridge generation.
- **Audio clip** — like a clip but tinted from its hue with a **waveform** drawn as a single SVG
  `<path>` (mirror-filled silhouette, `preserveAspectRatio="none"` so it stretches to the clip width).
  AI music track (A2) is tinted violet.
- **Playhead** — a 2px `var(--accent)` vertical line spanning ruler + all lanes, with a small handle
  at top. Position = `playheadSeconds / duration * 100%`.

### Generation settings rail (the new part)
Mirror the controls from `apps/web/src/screens/VideoStudio.jsx` so the same knobs that generate video
elsewhere are available in the editor. Structure, top to bottom:

1. **Contextual header** — eyebrow + selected item name, then a 2×2 grid of **context actions** that
   change with the selection:
   - Video clip → **Extend clip**, **Regenerate/Replace**, **Extract frame**, **Variation**
   - AI clip / keyframe → **Generate across keys**, **Add key image**, **Extend from key**
   - Gap → **Generate bridge (first↔last frame)**, **Generate to fill**, **Ripple close gap**
   - Audio → **Regenerate music / Generate SFX**, **Match to cut**, **Voiceover**, **Ducking**
   The primary action reads as a filled violet (AI) button; the rest are outlined violet.
2. **Model & quality** — `Video model` select (real ids: `ltx_2_3`, `ltx_10eros`, `wan_ti2v_5b`,
   `wan_t2v_14b`, `wan_i2v_14b`, `wan_vace_a14b`, `svd`, `bernini`, `scail_2`) + quality segmented
   control **Draft / Balanced / Final** (values `fast` / `balanced` / `best`, per `jobTypes.js`
   `qualityChoices`).
3. **Preset** — select (`presets` from context) + a save-preset icon button.
4. **Output** — 2×2: **Resolution** select (`1280x720`, `768x512`, `768x768`, `720x1280`, `1024x576`,
   `512x768`), **Frame rate** select (24/25/30), **Duration (s)** number (1–15), **Motion** strength
   slider (0–1, shown as %).
5. **LoRAs** — list of video LoRAs, each row = on/off toggle + name (mono) + weight slider (0–1) + %
   readout, and an "+ Add" button. (Real weights ride `advanced` per `VideoStudio.jsx`.)
6. **Seed** — text input + randomize (dice) button. **Negative prompt** — textarea.
7. **Advanced** (collapsible) — **Sampler** (`default/euler/dpm++ 2m/unipc`), **Scheduler**
   (`default/karras/sgm_uniform/beta`), **Steps** (override, blank = auto), **Guidance** (override),
   **Generation tier** chips **Q4 / Q8 / BF16** (default `q4`), and a **Lightning (4-step)** toggle
   (Wan 2.2 A14B fast distilled).
8. **Footer** — full-width **Generate** button (teal→violet gradient) + a mono line summarizing
   `duration · resolution · fps · queues to your GPU`.

---

## Interactions & Behavior
- **Scrub:** mouse-down/drag on the ruler sets `playheadSeconds` (pauses playback). Timecode readout
  updates live (format `MM:SS:FF` at the timeline fps).
- **Play/Pause:** toggles a rAF loop that advances the playhead; wraps to 0 at end. Space bar in the
  real screen (already wired in `EditorScreen.jsx`).
- **Select:** clicking a clip / gap / keyframe / audio / marker selects it, updates the inspector-side
  context actions and the program monitor. Selecting a **storyboard card** also moves the playhead to
  that key's time and selects its clip (keeps preview + timeline in sync).
- **Zoom:** `–`/`+` scales `pxPerSecond` (mock range ≈ 0.6×–2.6×); content width grows and the lane
  scrolls; all positions are % so nothing else recomputes.
- **Toggles/sliders:** quality chips, quant chips, LoRA on/off + weight, motion, lightning, and all
  selects are live-controlled.
- **Transitions/AI:** map the context actions to the existing timeline generation calls already in
  `EditorScreen.jsx` — `extendSelectedClip`, `replaceSelectedItem`, `bridgeAfterSelectedClip`,
  `extractFrame`, and `queueTimelineVideoJob` (modes `extend_clip`, `image_to_video`, `video_bridge`).

## State Management
The real screen already owns most of this; reuse it rather than re-inventing:
- From `useTimelines` / context: `activeTimeline`, `timelines`, `selectedTimelineId`, `mediaAssets`,
  `createTimeline`, `saveTimeline`, `exportTimeline`, `extractTimelineFrame`, `queueTimelineVideoJob`,
  history/undo-redo.
- New local UI state for the redesign: `selectedItemId` (+ selection kind: clip/gap/key/marker/audio),
  `playheadSeconds`, `isPlaying`, `zoom` (pxPerSecond multiplier), storyboard/collapse flags, and a
  **generation-settings object** (model, quality, preset, resolution, fps, duration, motion, seed,
  negativePrompt, loras[{id,name,weight,on}], sampler, scheduler, schedulerShift, steps, guidance,
  lightning, quant, advancedOpen) — the same fields Video Studio persists via `loadStudioSettings`.
- Timeline geometry: clip `left%` = `start/duration`, `width%` = `(end-start)/duration`; content
  width in px = `duration * BASE_PX_PER_SEC * zoom`.

## Design Tokens
Use the **existing** tokens from `apps/web/src/styles.css` — do not hardcode new hex. The editor is
shown on the **dark** ramp:

| Token | Dark value | Use |
| --- | --- | --- |
| `--bg` | `oklch(0.165 0.012 240)` | editor surface |
| `--bg-2` | `oklch(0.145 0.012 240)` | rails, lane background |
| `--surface` | `oklch(0.205 0.012 240)` | cards, controls |
| `--surface-2` | `oklch(0.235 0.014 240)` | insets |
| `--border` | `oklch(0.285 0.014 240)` | hairlines |
| `--border-strong` | `oklch(0.36 0.016 240)` | stronger dividers |
| `--text` / `--text-muted` / `--text-faint` | `0.96 / 0.72 / 0.56` L @ hue 240 | text ramp |
| `--accent` (teal) | `oklch(0.74 0.11 178)` | primary, playhead, selection, transport |
| `--accent-strong` / `--accent-soft` / `--accent-fg` | per stylesheet | accent variants |
| `--warm` | `oklch(0.78 0.1 45)` | timeline markers |
| **AI accent (new)** | `oklch(0.7 0.15 300)` (violet) | all AI/generative affordances |

- **AI accent:** the one value not in the current stylesheet. It intentionally distinguishes
  *generative* actions from the teal primary, harmonized to the same L/C family as the accent. Add it
  as a token (e.g. `--ai`) alongside the existing ramp. In light mode use `oklch(0.55 0.16 300)`.
- **Accent is swappable:** the app already supports `[data-accent]` (teal/indigo/violet/cobalt/…);
  the mock's tokens follow the same hue-driven pattern.
- **Radii:** `--r-xs 6 / --r-sm 8 / --r-md 12 / --r-lg 16 / --r-pill 999`.
- **Type:** `--font-ui` = "Plus Jakarta Sans"; `--font-mono` = "JetBrains Mono" (timecodes, filenames,
  numeric readouts). Both already loaded by the app.
- **Shadows:** `--shadow-sm/md/lg` per stylesheet; clips use a soft `rgba(0,0,0,.3)` drop, selection a
  double accent ring.

### Theme note
The mock defaults to the **dark** ramp because pro video tools are dark. The app defaults to light and
has a dark theme available. Decide with the team whether the editor forces dark locally or follows the
global theme — the design works in both (the prototype's `theme` tweak renders a light variant using
the `:root` light ramp).

## Assets
- **No raster assets.** All clip/asset/preview imagery in the mock is a CSS gradient placeholder with a
  monospace label — in the app these become real asset thumbnails/frames from `mediaAssets` /
  `AssetMedia`.
- **Icons:** use the existing set in `apps/web/src/components/Icons.jsx` (Video, Play, Pause, Plus,
  Wand, Stars/Sparkle for AI, Save, Refresh, Trash, Sliders, Model, etc.). The mock's inline SVGs are
  drawn to match those paths.
- **Waveforms** are generated (SVG path), not image files.

## Files
- `screenshots/01-full-editor.png` — toolbar, media bin, program monitor, generation-settings rail.
- `screenshots/02-storyboard-timeline.png` — storyboard strip above the full timeline, LoRAs + Generate.
- `Video Editor.dc.html` — the interactive prototype. Open in a browser. Implement option **`2a`**
  (top of the canvas). `1a` and `1b` below it are earlier explorations for reference only.
- Reference source in the SceneWorks repo (`SceneWorks/SceneWorks`, `apps/web/src/`):
  `screens/EditorScreen.jsx`, `screens/VideoStudio.jsx`, `timeline.js`, `hooks/useTimelines.js`,
  `components/Icons.jsx`, `components/WorkPanel.jsx`, `styles.css`, `jobTypes.js`.
